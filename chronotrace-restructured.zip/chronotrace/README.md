# ChronoTrace

Passive activity reconstruction: a Windows agent reports the foreground app/window, and the
website turns that stream into a timeline, a daily synthesis, a re-entry briefing and an AI assistant.

## Folder structure

```
chronotrace/
├── frontend/              React 19 + Vite + Tailwind (the website)
│   ├── index.html
│   ├── vite.config.ts
│   └── src/
│       ├── main.tsx       React entry point
│       ├── App.tsx        Screen flow + tab routing + polling
│       ├── index.css
│       ├── assets/images/
│       └── components/    One file per screen / view
├── backend/               Express 4 API + session auth + JSON storage
│   ├── server.ts          All API routes (auth, device, ingest, analytics, AI)
│   └── data/              Runtime data (git-ignored)
├── agent/                 Windows (also macOS/Linux) Python agent
│   └── chronotrace_agent.py
├── shared/                Types used by BOTH frontend and backend
│   └── types/chronotrace.ts
├── docs/
│   └── ARCHITECTURE.md    Screen flow, data flow, known issues, target design
├── archive/               Unused code and duplicate files, kept for reference
├── package.json           One set of dependencies and scripts for the whole project
├── tsconfig.json
└── .env.example
```

## Setup

Requires Node 20+ and Python 3.10+ (for the agent, standard library only).

```bash
npm install
cp .env.example .env        # add GEMINI_API_KEY if you want the AI features
npm run dev                 # http://localhost:3000  (Express + Vite dev server)
```

Production:

```bash
npm run build               # builds frontend/ into dist/
npm start                   # serves dist/ and the API
```

Other scripts: `npm run typecheck`, `npm run agent` (runs the agent locally).

## Using the Windows agent

1. Sign in on the website and open the device setup screen.
2. Download the agent (`chronotrace_agent.py`) and run it with Python: `python chronotrace_agent.py`.
3. Keep it running. The site shows "Connected" once heartbeats arrive.

See `docs/ARCHITECTURE.md` for how the pieces talk to each other and what needs fixing before this is shared.
