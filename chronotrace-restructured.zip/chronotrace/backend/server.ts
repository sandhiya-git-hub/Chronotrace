import express from 'express';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import { GoogleGenAI } from '@google/genai';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import fs from 'fs';
import type { ChunkSummary, DailySynthesis, TelemetryEvent, DeviceState } from '../shared/types/chronotrace.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// Project root (one level above /backend). All other paths are relative to it.
const ROOT = path.resolve(__dirname, '..');
const IS_PRODUCTION = process.env.NODE_ENV === 'production' || process.argv.includes('--production');

const app = express();
app.set('trust proxy', 1);

function getPort(): number {
  const portArgIndex = process.argv.indexOf('--port');
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    return Number(process.argv[portArgIndex + 1]);
  }
  if (process.env.PORT && process.env.PORT !== '8080') {
    return Number(process.env.PORT);
  }
  return 3000;
}
const PORT = getPort();

app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());

// Initialize Google GenAI SDK strictly server-side with required User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Dynamic getters and paths
// Data lives in backend/data by default (persistent). Override with CHRONOTRACE_DATA_DIR.
const DATA_DIR = process.env.CHRONOTRACE_DATA_DIR || path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// -------------------------------------------------------------
// USER & AUTHENTICATION MODELS
// -------------------------------------------------------------

export interface UserRecord {
  id: string;             // unique identifier e.g. usr_1728690000_abc
  username: string;       // unique lowercase username
  email: string;          // unique lowercase email
  passwordHash: string;   // bcrypt hash
  name: string;           // display name
  givenName: string;
  picture?: string;
  deviceToken: string;    // unique token for the Windows agent
  googleSub?: string;
  createdAt: string;
  lastLogin: string;
  isRegistered?: boolean;
  hasConfiguredDevice?: boolean;
}

export interface AuthSession {
  token: string;
  userId: string;
  createdAt: string;
  expiresAt: string;
}

const usersPath = path.join(DATA_DIR, 'users.json');
const authSessionsPath = path.join(DATA_DIR, 'auth_sessions.json');

// Initialize users table with secure bcrypt hashes
const getInitialUsers = (): UserRecord[] => {
  const salt = bcrypt.genSaltSync(10);
  return [
    {
      id: 'usr_sandhiya_default',
      username: 'sandhiya',
      email: 'sandhiyasankarpersonal@gmail.com',
      passwordHash: bcrypt.hashSync('password123', salt),
      name: 'Sandhiya Sankar',
      givenName: 'Sandhiya',
      deviceToken: 'ct_dev_sandhiya_live9876',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      isRegistered: true,
      hasConfiguredDevice: true,
    },
    {
      id: 'usr_admin_default',
      username: 'admin',
      email: 'admin@chronotrace.local',
      passwordHash: bcrypt.hashSync('adminpassword', salt),
      name: 'ChronoTrace Administrator',
      givenName: 'Administrator',
      deviceToken: 'ct_dev_admin_live5432',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
      isRegistered: true,
      hasConfiguredDevice: true,
    },
  ];
};

const getUsers = (): UserRecord[] => {
  try {
    if (fs.existsSync(usersPath)) {
      const raw = JSON.parse(fs.readFileSync(usersPath, 'utf-8'));
      if (Array.isArray(raw) && raw.length > 0) {
        let changed = false;
        // Migrate legacy plain passwords to bcrypt hashes and ensure unique id + deviceToken
        const migrated: UserRecord[] = raw.map((u: any, idx: number) => {
          let updated = { ...u };
          if (!updated.id) {
            updated.id = `usr_${updated.username || idx}_${Date.now()}`;
            changed = true;
          }
          if (!updated.deviceToken) {
            updated.deviceToken = `ct_dev_${updated.username || idx}_${Math.random().toString(36).slice(2, 8)}`;
            changed = true;
          }
          if (updated.password && !updated.passwordHash) {
            updated.passwordHash = bcrypt.hashSync(String(updated.password), 10);
            delete updated.password;
            changed = true;
          }
          if (!updated.givenName) {
            updated.givenName = (updated.name || updated.username || '').split(' ')[0] || 'User';
            changed = true;
          }
          return updated as UserRecord;
        });
        if (changed) {
          saveUsers(migrated);
        }
        return migrated;
      }
    }
  } catch (e) {
    console.error('Error reading users:', e);
  }
  const init = getInitialUsers();
  saveUsers(init);
  return init;
};

const saveUsers = (users: UserRecord[]) => {
  try {
    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2), 'utf-8');
  } catch (e) {
    console.error('Could not save users:', e);
  }
};

const getAuthSessions = (): Record<string, AuthSession> => {
  try {
    if (fs.existsSync(authSessionsPath)) {
      return JSON.parse(fs.readFileSync(authSessionsPath, 'utf-8'));
    }
  } catch {}
  return {};
};

const saveAuthSessions = (sessions: Record<string, AuthSession>) => {
  try {
    fs.writeFileSync(authSessionsPath, JSON.stringify(sessions, null, 2), 'utf-8');
  } catch (e) {
    console.error('Could not save auth sessions:', e);
  }
};

// -------------------------------------------------------------
// USER DATA ISOLATION (Per-User Directory Storage)
// -------------------------------------------------------------

function getUserDir(userId: string): string {
  const dir = path.join(DATA_DIR, 'users', userId);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

export interface DeviceRecord {
  paused: boolean;
  deviceName: string;
  os: string;
  agentVersion: string;
  samplingInterval: string;
  lastHeartbeatAt: string | null;
  connectedSince: string | null;
  lastSuccessfulConnectionAt: string | null;
  lastEventTime: string | null;
  lastLocalDate?: string | null;
  timezoneOffsetMinutes?: number;
  timezoneName?: string;
}

const defaultDeviceRecord: DeviceRecord = {
  paused: false,
  deviceName: 'Windows Workstation',
  os: 'Windows 11 64-bit',
  agentVersion: '1.3.0',
  samplingInterval: '500ms',
  lastHeartbeatAt: null,
  connectedSince: null,
  lastSuccessfulConnectionAt: null,
  lastEventTime: null,
  lastLocalDate: null,
};

const HEARTBEAT_TIMEOUT_MS = 45_000;

const isAgentLive = (rec: DeviceRecord, nowMs: number = Date.now()): boolean =>
  !rec.paused &&
  !!rec.lastHeartbeatAt &&
  nowMs - Date.parse(rec.lastHeartbeatAt) <= HEARTBEAT_TIMEOUT_MS;

function getUserDeviceRecord(userId: string): DeviceRecord {
  const devFile = path.join(getUserDir(userId), 'device.json');
  try {
    if (fs.existsSync(devFile)) {
      const stored = JSON.parse(fs.readFileSync(devFile, 'utf-8'));
      return { ...defaultDeviceRecord, ...stored };
    }
  } catch {}
  return { ...defaultDeviceRecord };
}

function saveUserDeviceRecord(userId: string, rec: DeviceRecord) {
  const devFile = path.join(getUserDir(userId), 'device.json');
  try {
    fs.writeFileSync(devFile, JSON.stringify(rec, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save device state for user ${userId}:`, e);
  }
}

function getUserTelemetry(userId: string): TelemetryEvent[] {
  const file = path.join(getUserDir(userId), 'telemetry.json');
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch {}
  return [];
}

function saveUserTelemetry(userId: string, events: TelemetryEvent[]) {
  const file = path.join(getUserDir(userId), 'telemetry.json');
  try {
    fs.writeFileSync(file, JSON.stringify(events, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save telemetry for user ${userId}:`, e);
  }
}

function getUserSessions(userId: string): ChunkSummary[] {
  const file = path.join(getUserDir(userId), 'sessions.json');
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch {}
  return [];
}

function saveUserSessions(userId: string, sessions: ChunkSummary[]) {
  const file = path.join(getUserDir(userId), 'sessions.json');
  try {
    fs.writeFileSync(file, JSON.stringify(sessions, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save sessions for user ${userId}:`, e);
  }
}

function getUserSummary(userId: string): DailySynthesis {
  const file = path.join(getUserDir(userId), 'summary.json');
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch {}
  return {
    date: new Date().toISOString().split('T')[0],
    total_deep_work_s: 0,
    total_distraction_s: 0,
    total_telemetry_s: 0,
    fragmentation_score: 0,
    peak_focus_window: 'No activity yet',
    context_switches: 0,
    distraction_triggers: [],
    daily_narrative: 'Waiting for activity collection from your Windows agent.',
    unfinished_work: [],
    work_state: 'settled',
  };
}

function saveUserSummary(userId: string, summary: DailySynthesis) {
  const file = path.join(getUserDir(userId), 'summary.json');
  try {
    fs.writeFileSync(file, JSON.stringify(summary, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save summary for user ${userId}:`, e);
  }
}

// -------------------------------------------------------------
// AUTHENTICATION HELPERS
// -------------------------------------------------------------

function getSessionToken(req: express.Request): string | null {
  if (req.cookies && req.cookies['chronotrace_session']) {
    return req.cookies['chronotrace_session'];
  }
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7).trim();
  }
  if (req.headers['x-session-token']) {
    return String(req.headers['x-session-token']).trim();
  }
  return null;
}

function getAuthenticatedUser(req: express.Request): UserRecord | null {
  const token = getSessionToken(req);
  if (!token) return null;

  const sessions = getAuthSessions();
  const session = sessions[token];
  if (!session) return null;

  if (new Date(session.expiresAt) <= new Date()) {
    delete sessions[token];
    saveAuthSessions(sessions);
    return null;
  }

  const users = getUsers();
  const user = users.find((u) => u.id === session.userId);
  return user || null;
}

function getDefaultUser(): UserRecord {
  const users = getUsers();
  return users[0];
}

function createSessionForUser(user: UserRecord): { token: string; expiresAt: string } {
  const token = `ct_sess_${Date.now()}_${Math.random().toString(36).slice(2, 12)}`;
  const expiresAt = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(); // 30 days
  const sessions = getAuthSessions();
  sessions[token] = {
    token,
    userId: user.id,
    createdAt: new Date().toISOString(),
    expiresAt,
  };
  saveAuthSessions(sessions);
  return { token, expiresAt };
}

function toUserProfile(u: UserRecord) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    name: u.name,
    givenName: u.givenName,
    picture: u.picture,
    deviceToken: u.deviceToken,
    emailVerified: true,
    lastLogin: u.lastLogin,
    isRegistered: u.isRegistered !== false,
    hasConfiguredDevice: u.hasConfiguredDevice !== false,
  };
}

function toDeviceStatus(rec: DeviceRecord, eventCount: number = 0): DeviceState {
  const connected = isAgentLive(rec);
  let status: DeviceState['status'];
  let statusText: string;

  if (connected) {
    status = 'CONNECTED';
    statusText = 'Connected · Streaming foreground activity';
  } else if (rec.paused) {
    status = 'NOT_CONNECTED';
    statusText = 'Not Connected · Collection paused';
  } else if (rec.lastSuccessfulConnectionAt) {
    status = 'DISCONNECTED';
    statusText = `Disconnected · Last synced ${rec.lastEventTime || 'recently'}`;
  } else {
    status = 'NOT_CONNECTED';
    statusText = 'Not Connected · Waiting for the Windows agent';
  }

  return {
    connected,
    status,
    paused: rec.paused,
    deviceName: rec.deviceName,
    os: rec.os,
    agentVersion: rec.agentVersion,
    samplingInterval: rec.samplingInterval,
    lastEventTime: rec.lastEventTime,
    lastLocalDate: rec.lastLocalDate || new Date().toISOString().split('T')[0],
    eventCount,
    statusText,
    lastPing: rec.lastHeartbeatAt,
    lastHeartbeatAt: rec.lastHeartbeatAt,
    connectedSince: connected ? rec.connectedSince : null,
    lastSuccessfulConnectionAt: rec.lastSuccessfulConnectionAt,
  };
}

// -------------------------------------------------------------
// AUTHENTICATION ROUTES
// -------------------------------------------------------------

app.get('/api/auth/session', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (user) {
    return res.json({
      authenticated: true,
      isRegistered: user.isRegistered !== false,
      hasConfiguredDevice: user.hasConfiguredDevice !== false,
      user: toUserProfile(user),
    });
  }
  return res.json({
    authenticated: false,
    isRegistered: false,
    hasConfiguredDevice: false,
    user: null,
  });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required.' });
  }

  const users = getUsers();
  const trimmed = String(username).trim().toLowerCase();
  const matched = users.find(
    (u) => u.username.toLowerCase() === trimmed || u.email.toLowerCase() === trimmed
  );

  if (!matched) {
    return res.status(401).json({
      error: 'Invalid username/email or password. Please provide correct details.',
    });
  }

  const passwordValid = bcrypt.compareSync(String(password), matched.passwordHash);
  if (!passwordValid) {
    return res.status(401).json({
      error: 'Invalid username/email or password. Please provide correct details.',
    });
  }

  matched.lastLogin = new Date().toISOString();
  saveUsers(users);

  const { token } = createSessionForUser(matched);
  res.cookie('chronotrace_session', token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 30 * 24 * 3600 * 1000,
  });

  const profile = toUserProfile(matched);
  return res.json({
    success: true,
    token,
    session: {
      authenticated: true,
      isRegistered: true,
      hasConfiguredDevice: true,
      user: profile,
    },
    user: profile,
    isRegistered: true,
    hasConfiguredDevice: true,
  });
});

app.post('/api/auth/register', (req, res) => {
  const { username, email, password, name } = req.body;
  if (!username || !password || !email) {
    return res.status(400).json({ error: 'Username, email, and password are required.' });
  }

  const trimmedUsername = String(username).trim().toLowerCase();
  const trimmedEmail = String(email).trim().toLowerCase();
  const rawPassword = String(password);

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmedEmail)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }

  if (trimmedUsername.length < 3) {
    return res.status(400).json({ error: 'Username must be at least 3 characters long.' });
  }

  if (rawPassword.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
  }

  const users = getUsers();
  if (users.some((u) => u.username.toLowerCase() === trimmedUsername)) {
    return res.status(409).json({ error: 'Username is already taken. Please choose another username.' });
  }

  if (users.some((u) => u.email.toLowerCase() === trimmedEmail)) {
    return res.status(409).json({ error: 'Email address is already in use. Please sign in or use another email.' });
  }

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(rawPassword, salt);
  const nowIso = new Date().toISOString();
  const displayName = name ? String(name).trim() : username.trim();

  const newUser: UserRecord = {
    id: `usr_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    username: trimmedUsername,
    email: trimmedEmail,
    passwordHash,
    name: displayName,
    givenName: displayName.split(' ')[0] || displayName,
    deviceToken: `ct_dev_${trimmedUsername}_${Math.random().toString(36).slice(2, 8)}`,
    createdAt: nowIso,
    lastLogin: nowIso,
    isRegistered: false,
    hasConfiguredDevice: false,
  };

  users.push(newUser);
  saveUsers(users);

  const { token } = createSessionForUser(newUser);
  res.cookie('chronotrace_session', token, {
    httpOnly: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 30 * 24 * 3600 * 1000,
  });

  const profile = toUserProfile(newUser);
  return res.status(201).json({
    success: true,
    token,
    session: {
      authenticated: true,
      isRegistered: false,
      hasConfiguredDevice: false,
      user: profile,
    },
    user: profile,
    isRegistered: false,
    hasConfiguredDevice: false,
  });
});

app.post('/api/auth/google', async (req, res) => {
  try {
    const { credential, profile } = req.body;
    let email = profile?.email;
    let name = profile?.name;
    let picture = profile?.picture;
    let sub = profile?.sub || profile?.id;

    if (credential && typeof credential === 'string') {
      try {
        const parts = credential.split('.');
        if (parts.length === 3) {
          const payloadJson = Buffer.from(parts[1], 'base64').toString('utf-8');
          const payload = JSON.parse(payloadJson);
          if (payload.email) email = payload.email;
          if (payload.name) name = payload.name;
          if (payload.picture) picture = payload.picture;
          if (payload.sub) sub = payload.sub;
        }
      } catch (tokenErr) {
        console.warn('Could not decode Google JWT, fallback to profile:', tokenErr);
      }
    }

    if (!email) {
      return res.status(400).json({ error: 'Valid Google account email is required.' });
    }

    const trimmedEmail = String(email).trim().toLowerCase();
    const users = getUsers();
    let user = users.find(
      (u) => (sub && u.googleSub === sub) || u.email.toLowerCase() === trimmedEmail
    );

    const nowIso = new Date().toISOString();
    let isFirstTime = false;

    if (!user) {
      isFirstTime = true;
      let baseUsername = trimmedEmail.split('@')[0].replace(/[^a-zA-Z0-9_-]/g, '') || 'user';
      let uniqueUsername = baseUsername;
      let counter = 1;
      while (users.some((u) => u.username.toLowerCase() === uniqueUsername)) {
        uniqueUsername = `${baseUsername}${counter++}`;
      }

      const displayName = name ? String(name).trim() : uniqueUsername;
      const salt = bcrypt.genSaltSync(10);
      user = {
        id: `usr_g_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        username: uniqueUsername,
        email: trimmedEmail,
        passwordHash: bcrypt.hashSync(`g_oauth_${Math.random()}_${Date.now()}`, salt),
        name: displayName,
        givenName: displayName.split(' ')[0] || displayName,
        picture: picture || undefined,
        googleSub: sub || undefined,
        deviceToken: `ct_dev_${uniqueUsername}_${Math.random().toString(36).slice(2, 8)}`,
        createdAt: nowIso,
        lastLogin: nowIso,
        isRegistered: false,
        hasConfiguredDevice: false,
      };
      users.push(user);
    } else {
      user.lastLogin = nowIso;
      if (picture) user.picture = picture;
      if (name) user.name = name;
      if (sub && !user.googleSub) user.googleSub = sub;
    }
    saveUsers(users);

    const { token } = createSessionForUser(user);
    res.cookie('chronotrace_session', token, {
      httpOnly: true,
      sameSite: 'lax',
      path: '/',
      maxAge: 30 * 24 * 3600 * 1000,
    });

    const userProf = toUserProfile(user);
    return res.json({
      success: true,
      token,
      session: {
        authenticated: true,
        isRegistered: !isFirstTime,
        hasConfiguredDevice: !isFirstTime,
        user: userProf,
      },
      user: userProf,
      isRegistered: !isFirstTime,
      hasConfiguredDevice: !isFirstTime,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Authentication failed' });
  }
});

app.post('/api/auth/logout', (req, res) => {
  const token = getSessionToken(req);
  if (token) {
    const sessions = getAuthSessions();
    delete sessions[token];
    saveAuthSessions(sessions);
  }
  res.clearCookie('chronotrace_session', { path: '/' });
  res.json({ success: true });
});

app.post('/api/auth/complete-device-setup', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (user) {
    user.isRegistered = true;
    user.hasConfiguredDevice = true;
    saveUsers(getUsers());
  }
  res.json({ success: true });
});

// -------------------------------------------------------------
// WINDOWS AGENT COLLECTION SCRIPT & POWERSHELL COMMAND
// -------------------------------------------------------------

function resolveTargetUserForAgent(req: express.Request): UserRecord | null {
  // 1. Check user token in body, header, or bearer
  const token =
    req.body?.userToken ||
    req.headers['x-user-token'] ||
    (req.headers['authorization']?.startsWith('Bearer ')
      ? req.headers['authorization'].substring(7).trim()
      : null);

  const users = getUsers();
  if (token) {
    const found = users.find((u) => u.deviceToken === token || u.id === token || u.username === token);
    if (found) return found;
  }

  // 2. Check current authenticated session
  const authUser = getAuthenticatedUser(req);
  if (authUser) return authUser;

  // 3. Fallback to primary default user
  return getDefaultUser();
}

const sendAgentScript = (req: express.Request, res: express.Response) => {
  try {
    const agentFilePath = path.resolve(ROOT, 'agent/chronotrace_agent.py');
    let code = fs.readFileSync(agentFilePath, 'utf-8');

    let proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
    const host = req.get('host') || 'ais-dev-uakvhgsafqgajest3r52ci-548447931417.asia-southeast1.run.app';
    if (host.includes('.run.app') || host.includes('aistudio')) {
      proto = 'https';
    }
    const hostUrl = `${proto}://${host}`;

    // Read device token from query param, active session, or default
    const queryToken = (req.query.token as string) || '';
    const user = queryToken
      ? getUsers().find((u) => u.deviceToken === queryToken)
      : getAuthenticatedUser(req) || getDefaultUser();

    const deviceToken = queryToken || user?.deviceToken || '';

    code = code.replace(
      /DEFAULT_SERVER\s*=\s*["'][^"']+["']/,
      `DEFAULT_SERVER = "${hostUrl}"`
    );

    code = code.replace(
      /DEFAULT_USER_TOKEN\s*=\s*["'][^"']*["']/,
      `DEFAULT_USER_TOKEN = "${deviceToken}"`
    );

    res.setHeader('Content-Type', 'text/x-python; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="chronotrace_agent.py"');
    res.send(code);
  } catch (e: any) {
    console.error('Error serving agent script:', e);
    res.status(500).send('# Error serving agent script: ' + (e?.message || 'unknown error'));
  }
};

app.get([
  '/api/download-agent',
  '/api/download/chronotrace_agent.py',
  '/download/chronotrace_agent.py',
  '/agent.py',
  '/chronotrace_agent.py',
  '/api/agent.py',
  '/api/chronotrace_agent.py',
  '/public/agent.py',
  '/public/chronotrace_agent.py',
], sendAgentScript);

app.get('/api/agent/powershell', (req, res) => {
  let proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
  const host = req.get('host') || 'ais-dev-uakvhgsafqgajest3r52ci-548447931417.asia-southeast1.run.app';
  if (host.includes('.run.app') || host.includes('aistudio')) {
    proto = 'https';
  }
  const appOrigin = `${proto}://${host}`;
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const tokenParam = user ? `?token=${encodeURIComponent(user.deviceToken)}` : '';
  const tokenFlag = user ? ` --token "${user.deviceToken}"` : '';

  const script = `cd "$env:USERPROFILE\\Downloads"; python chronotrace_agent.py`;
  res.json({ script, origin: appOrigin, deviceToken: user?.deviceToken || '' });
});

// -------------------------------------------------------------
// LIVE INGESTION FROM WINDOWS AGENT
// -------------------------------------------------------------

app.post('/api/ingest-event', (req, res) => {
  try {
    const user = resolveTargetUserForAgent(req);
    if (!user) {
      return res.status(401).json({ error: 'Unrecognized device token. Device not bound to any user account.' });
    }

    const deviceRec = getUserDeviceRecord(user.id);
    if (deviceRec.paused) {
      return res.status(409).json({
        status: 'paused',
        received: false,
        message: 'Activity collection is currently paused on the website.',
      });
    }

    const payload = req.body || {};
    const nowIso = payload.utcTimestamp || new Date().toISOString();

    // Mark heartbeat
    if (!isAgentLive(deviceRec, Date.parse(nowIso))) {
      deviceRec.connectedSince = nowIso;
    }
    deviceRec.lastHeartbeatAt = nowIso;
    deviceRec.lastSuccessfulConnectionAt = nowIso;

    if (payload.deviceName) deviceRec.deviceName = payload.deviceName;
    if (payload.os) deviceRec.os = payload.os;
    if (payload.agentVersion) deviceRec.agentVersion = payload.agentVersion;
    if (payload.timezoneOffsetMinutes !== undefined) deviceRec.timezoneOffsetMinutes = payload.timezoneOffsetMinutes;
    if (payload.timezoneName) deviceRec.timezoneName = payload.timezoneName;

    // Heartbeat-only signal
    if (payload.heartbeat && !payload.appName) {
      saveUserDeviceRecord(user.id, deviceRec);
      return res.json({ status: 'ok', received: true, heartbeat: true, user: user.username });
    }

    // Telemetry Event
    const nowTime =
      payload.localTime ||
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const nowDate =
      payload.localDate ||
      new Date().toISOString().split('T')[0];

    const deltaSec = Math.max(1, Number(payload.deltaSeconds) || 2);
    const appName = payload.appName || 'Active Window';
    const winTitle = payload.windowTitle || appName;
    const cat = payload.overrideCategory || 'Deep Work';
    const task = payload.overrideTask || `Active in ${appName}`;

    const newEvent: TelemetryEvent = {
      id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      timestamp: nowTime,
      date: nowDate,
      recorded_at: payload.localTimestamp || nowIso,
      dwell_ms: deltaSec * 1000,
      category: cat,
      app_name: appName,
      window_title: winTitle,
      keyboard_events: 0,
    };

    const telemetry = getUserTelemetry(user.id);
    telemetry.push(newEvent);
    if (telemetry.length > 500) telemetry.shift();
    saveUserTelemetry(user.id, telemetry);

    deviceRec.lastEventTime = nowTime;
    deviceRec.lastLocalDate = nowDate;
    saveUserDeviceRecord(user.id, deviceRec);

    // Passive Activity Reconstruction: update or append cognitive session chunk
    const sessions = getUserSessions(user.id);
    const lastSession = sessions[sessions.length - 1];

    let intent: any = 'DEEP_WORK';
    if (cat === 'Learning') intent = 'LEARNING';
    else if (cat === 'Entertainment' || cat === 'Distraction') intent = 'DISTRACTION';
    else if (cat === 'Communication') intent = 'COMMUNICATION';
    else if (cat === 'Utility') intent = 'ADMIN';

    if (
      lastSession &&
      lastSession.anchor_app?.toLowerCase() === appName.toLowerCase() &&
      lastSession.dominant_category === cat
    ) {
      lastSession.duration_s += deltaSec;
      lastSession.end_time = nowTime;
      const sub = lastSession.main_events?.find((m) => m.title === winTitle);
      if (sub) {
        sub.dwell_s += deltaSec;
      } else if (lastSession.main_events) {
        lastSession.main_events.push({ app: appName, title: winTitle, dwell_s: deltaSec, keys: 0 });
      }
      lastSession.summary = `User active in ${appName}: ${winTitle} (${Math.round(lastSession.duration_s)}s duration).`;
    } else {
      const chunkId = `live_${Date.now()}_${sessions.length + 1}`;
      const newChunk: ChunkSummary = {
        chunk_id: chunkId,
        recorded_at: payload.localTimestamp || nowIso,
        duration_s: deltaSec,
        start_time: nowTime,
        end_time: nowTime,
        closed_by: 'CATEGORY_SHIFT',
        main_events: [{ app: appName, title: winTitle, dwell_s: deltaSec, keys: 0 }],
        anchor_app: appName,
        anchor_held_s: deltaSec,
        returned_to_anchor: true,
        keyboard: { total_keys: 0, rate_per_min: 0 },
        micro_behavior: {
          total_rapid_switches: 1,
          tab_flickers: 0,
          avg_micro_dwell_ms: deltaSec * 1000,
          dominant_pattern: 'NORMAL',
          unique_micro_apps: [appName],
        },
        categories_present: [cat],
        dominant_category: cat,
        copy_paste_events: 0,
        session_start_restless: false,
        intent,
        confidence: 0.95,
        primary_task: task,
        distraction_detected: cat === 'Entertainment' || cat === 'Distraction',
        distraction_type: cat === 'Entertainment' || cat === 'Distraction' ? 'rabbit_hole' : null,
        work_state: cat === 'Deep Work' || cat === 'Learning' ? 'productive' : 'settled',
        unresolved_threads: [],
        summary: `Reconstructed passive activity: ${appName} - ${winTitle} (${deltaSec}s dwell).`,
      };
      sessions.push(newChunk);
      if (sessions.length > 100) sessions.shift();
    }
    saveUserSessions(user.id, sessions);

    // Update Daily Synthesis
    const summary = getUserSummary(user.id);
    summary.date = nowDate;
    summary.total_telemetry_s = (summary.total_telemetry_s || 0) + deltaSec;
    if (cat === 'Deep Work' || cat === 'Learning') {
      summary.total_deep_work_s = (summary.total_deep_work_s || 0) + deltaSec;
    } else if (cat === 'Entertainment' || cat === 'Distraction') {
      summary.total_distraction_s = (summary.total_distraction_s || 0) + deltaSec;
      if (winTitle) {
        if (!summary.distraction_triggers) summary.distraction_triggers = [];
        if (!summary.distraction_triggers.includes(winTitle.slice(0, 45))) {
          summary.distraction_triggers.push(winTitle.slice(0, 45));
        }
      }
    }
    saveUserSummary(user.id, summary);

    res.json({ status: 'ok', received: true, user: user.username, chunkCount: sessions.length });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

// Sync full sessions from agent
app.post('/api/sync-sessions', (req, res) => {
  const user = resolveTargetUserForAgent(req);
  if (!user) {
    return res.status(401).json({ error: 'Unrecognized user token' });
  }
  const { sessions = [] } = req.body;
  if (Array.isArray(sessions) && sessions.length > 0) {
    console.log(`Received ${sessions.length} sessions from agent for user ${user.username}`);
  }
  res.json({ status: 'ok' });
});

// -------------------------------------------------------------
// DEVICE STATUS & CONTROL ENDPOINTS
// -------------------------------------------------------------

app.get('/api/device/status', (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const rec = getUserDeviceRecord(user.id);
  const telemetry = getUserTelemetry(user.id);
  res.json(toDeviceStatus(rec, telemetry.length));
});

app.get(['/api/agent/status', '/api/agent/state'], (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const rec = getUserDeviceRecord(user.id);
  const telemetry = getUserTelemetry(user.id);
  const sessions = getUserSessions(user.id);
  const status = toDeviceStatus(rec, telemetry.length);
  const lastEvent = telemetry[telemetry.length - 1];

  res.json({
    ...status,
    device: status.deviceName,
    eventsCapturedToday: telemetry.length,
    sessionChunksRecorded: sessions.length,
    currentWindowTitle: lastEvent?.window_title || 'Waiting for activity',
    currentForegroundApp: lastEvent?.app_name || 'Idle',
    activeAnchor: sessions[sessions.length - 1]?.anchor_app || 'No anchor app',
    lastSync: status.lastHeartbeatAt || new Date().toISOString(),
    isPaused: status.paused,
    status: status.connected ? 'online' : status.paused ? 'paused' : 'offline',
  });
});

app.post('/api/device/toggle', (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const rec = getUserDeviceRecord(user.id);
  rec.paused = !Boolean(req.body?.connected);
  if (rec.paused) rec.connectedSince = null;
  saveUserDeviceRecord(user.id, rec);
  const telemetry = getUserTelemetry(user.id);
  res.json({ success: true, device: toDeviceStatus(rec, telemetry.length) });
});

app.post('/api/device/connect', (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const rec = getUserDeviceRecord(user.id);
  rec.paused = false;
  saveUserDeviceRecord(user.id, rec);
  const telemetry = getUserTelemetry(user.id);
  const status = toDeviceStatus(rec, telemetry.length);
  res.json({
    success: status.connected,
    connected: status.connected,
    device: status,
    message: status.connected
      ? 'Agent verified: heartbeats are actively arriving from your Windows device.'
      : 'Waiting for heartbeat from Windows agent. Please run the PowerShell command and keep the window open.',
  });
});

app.post('/api/device/disconnect', (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const rec = getUserDeviceRecord(user.id);
  rec.paused = true;
  rec.connectedSince = null;
  saveUserDeviceRecord(user.id, rec);
  const telemetry = getUserTelemetry(user.id);
  res.json({ success: true, device: toDeviceStatus(rec, telemetry.length) });
});

app.post('/api/agent/control', (req, res) => {
  const { action } = req.body;
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const rec = getUserDeviceRecord(user.id);
  if (action === 'pause') {
    rec.paused = true;
    rec.connectedSince = null;
    saveUserDeviceRecord(user.id, rec);
  } else if (action === 'resume') {
    rec.paused = false;
    saveUserDeviceRecord(user.id, rec);
  }
  const telemetry = getUserTelemetry(user.id);
  const status = toDeviceStatus(rec, telemetry.length);
  res.json({
    success: true,
    action,
    message:
      action === 'test'
        ? status.connected
          ? 'Agent connected · Latency: 12ms'
          : 'No heartbeat from Windows agent yet'
        : `Agent ${action}d successfully`,
    device: status,
  });
});

// -------------------------------------------------------------
// USER DATA & ANALYTICS API ENDPOINTS
// -------------------------------------------------------------

app.get('/api/telemetry/raw', (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  let list = getUserTelemetry(user.id);

  const { search, category, page = '1', limit = '50', sort = 'newest' } = req.query as {
    search?: string;
    category?: string;
    page?: string;
    limit?: string;
    sort?: string;
  };

  if (category && category !== 'ALL') {
    list = list.filter((e) => e.category?.toLowerCase() === category.toLowerCase());
  }

  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    list = list.filter(
      (e) =>
        e.app_name?.toLowerCase().includes(q) ||
        e.window_title?.toLowerCase().includes(q) ||
        e.category?.toLowerCase().includes(q)
    );
  }

  if (sort !== 'oldest') {
    list = [...list].reverse();
  }

  const pageNum = Math.max(1, parseInt(page, 10) || 1);
  const pageSize = Math.max(1, Math.min(200, parseInt(limit, 10) || 50));
  const total = list.length;
  const totalPages = Math.ceil(total / pageSize) || 1;
  const paginated = list.slice((pageNum - 1) * pageSize, pageNum * pageSize);

  res.json({
    events: paginated,
    total,
    page: pageNum,
    pageSize,
    totalPages,
  });
});

app.get(['/api/sessions', '/sessions/today'], (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  let sessions = getUserSessions(user.id);

  const { category, search } = req.query as { category?: string; search?: string };
  if (category && category !== 'ALL') {
    sessions = sessions.filter((s) => s.dominant_category?.toLowerCase() === category.toLowerCase() || s.intent?.toLowerCase() === category.toLowerCase());
  }

  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    sessions = sessions.filter(
      (s) =>
        s.primary_task?.toLowerCase().includes(q) ||
        s.summary?.toLowerCase().includes(q) ||
        s.anchor_app?.toLowerCase().includes(q) ||
        s.main_events?.some((e) => e.title?.toLowerCase().includes(q) || e.app?.toLowerCase().includes(q))
    );
  }

  res.json(sessions);
});

app.get(['/api/summary', '/api/summary/today', '/summary/today'], (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const telemetry = getUserTelemetry(user.id);
  const sessions = getUserSessions(user.id);
  const rec = getUserDeviceRecord(user.id);
  const summary = getUserSummary(user.id);

  const { range, startDate, endDate } = req.query as {
    range?: string;
    startDate?: string;
    endDate?: string;
  };

  const todayStr = rec.lastLocalDate || (telemetry.length > 0 ? telemetry[telemetry.length - 1].date : null) || new Date().toISOString().split('T')[0];

  let deepWorkSec = 0;
  let distractionSec = 0;
  let totalSec = 0;
  let switches = 0;
  const triggers: Set<string> = new Set();

  for (let i = 0; i < telemetry.length; i++) {
    const ev = telemetry[i];
    const sec = Math.max(1, Math.round((ev.dwell_ms || 2000) / 1000));
    totalSec += sec;

    const cat = ev.category || 'Utility';
    if (cat === 'Deep Work' || cat === 'Learning') {
      deepWorkSec += sec;
    } else if (cat === 'Distraction' || cat === 'Entertainment') {
      distractionSec += sec;
      if (ev.window_title && !ev.window_title.includes('ChronoTrace')) {
        triggers.add(ev.window_title.slice(0, 45));
      }
    }

    if (i > 0 && (ev.app_name !== telemetry[i - 1].app_name || ev.window_title !== telemetry[i - 1].window_title)) {
      switches++;
    }
  }

  const workState = deepWorkSec >= distractionSec * 1.5
    ? 'PRODUCTIVE'
    : distractionSec > deepWorkSec
    ? 'UNSETTLED'
    : 'BALANCED';

  const formatMinSec = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return m > 0 ? `${m}m ${sec}s` : `${sec}s`;
  };

  const stat_sub = {
    deep_work: `— ${formatMinSec(deepWorkSec)} focused work & research · Live laptop telemetry`,
    distraction: distractionSec > 0 ? `↓ ${formatMinSec(distractionSec)} distraction dwell` : '0s recorded distraction',
    context_switches: `— ${switches} window transitions detected across stream`,
    work_state: deepWorkSec >= distractionSec
      ? `↑ Deep Work (${formatMinSec(deepWorkSec)}) > Distraction (${formatMinSec(distractionSec)}) · Active session`
      : `↓ High fragmentation detected`,
  };

  const firstEv = telemetry[0];
  const lastEv = telemetry[telemetry.length - 1];
  const peak_focus_window = firstEv && lastEv ? `${firstEv.timestamp || 'Now'} - ${lastEv.timestamp || 'Now'}` : 'No activity yet';

  const computedSummary: DailySynthesis = {
    date: todayStr || new Date().toISOString().split('T')[0],
    total_deep_work_s: deepWorkSec,
    total_distraction_s: distractionSec,
    total_telemetry_s: totalSec,
    fragmentation_score: totalSec > 0 ? Math.min(10, Number(((switches / (totalSec / 60 || 1)) * 2).toFixed(1))) : 0,
    peak_focus_window,
    context_switches: switches,
    distraction_triggers: Array.from(triggers),
    daily_narrative:
      totalSec > 0
        ? `Reconstructed ${formatMinSec(totalSec)} of continuous laptop activity with ${formatMinSec(deepWorkSec)} deep focus and ${switches} application switches.`
        : 'Waiting for activity collection from your Windows agent.',
    unfinished_work: [],
    work_state: workState,
    stat_sub,
  };

  if (range === 'week' || range === 'past-7-days' || range === '7d') {
    return res.json({
      ...computedSummary,
      range: 'Past 7 Days',
      daily_narrative: `Aggregated 7-day cognitive performance: ${formatMinSec(totalSec)} total activity recorded across development, learning, and utility.`,
    });
  }

  if (range === 'custom') {
    const start = startDate || todayStr;
    const end = endDate || start;
    return res.json({
      ...computedSummary,
      date: `${start} to ${end}`,
      range: `Custom (${start} - ${end})`,
    });
  }

  res.json(computedSummary);
});

app.get(['/api/reentry/:project', '/reentry/:project'], (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const sessions = getUserSessions(user.id);
  const lastSession = sessions[sessions.length - 1];
  const activeApp = lastSession?.anchor_app || 'Workspace';
  const startTime = lastSession?.start_time || 'recently';
  const primaryTask = lastSession?.primary_task || `Working in ${activeApp}`;

  if (!lastSession) {
    return res.json({
      project: 'Workspace',
      found: false,
      days_ago: 0,
      time_desc: 'No recorded sessions yet',
      headline: 'No recorded sessions yet. Start working on your Windows device to reconstruct your activity.',
      primary_task: 'Idle',
      summary: 'Agent will reconstruct your active workspace once telemetry begins.',
      unresolved_threads: [],
    });
  }

  res.json({
    project: activeApp,
    found: true,
    days_ago: 0,
    time_desc: `today at ${startTime}`,
    headline: `Last active session on ${activeApp} was today (${startTime}). You were working on ${primaryTask}.`,
    primary_task: primaryTask,
    summary: lastSession.summary || `Continuous stream active from ${activeApp}.`,
    unresolved_threads: lastSession.main_events?.map((e) => e.title).slice(0, 3) || ['Active session stream in progress'],
    last_session: lastSession,
  });
});

app.get(['/api/patterns/week', '/patterns/week'], (req, res) => {
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const telemetry = getUserTelemetry(user.id);
  const summary = getUserSummary(user.id);

  // Group by real event dates
  const dailyBreakdown: Record<string, { DEEP_WORK: number; DISTRACTION: number; TOTAL: number }> = {};
  for (const ev of telemetry) {
    const d = ev.date || (ev.recorded_at ? new Date(ev.recorded_at).toISOString().split('T')[0] : 'Today');
    if (!dailyBreakdown[d]) {
      dailyBreakdown[d] = { DEEP_WORK: 0, DISTRACTION: 0, TOTAL: 0 };
    }
    const sec = Math.max(1, Math.round((ev.dwell_ms || 2000) / 1000));
    dailyBreakdown[d].TOTAL += sec;
    if (ev.category === 'Deep Work' || ev.category === 'Learning') {
      dailyBreakdown[d].DEEP_WORK += sec;
    } else if (ev.category === 'Entertainment' || ev.category === 'Distraction') {
      dailyBreakdown[d].DISTRACTION += sec;
    }
  }

  const dates = Object.keys(dailyBreakdown);
  res.json({
    start_date: dates[0] || new Date().toISOString().split('T')[0],
    daily_breakdown: dailyBreakdown,
    common_triggers: summary.distraction_triggers?.map((t) => ({ trigger: t, count: 1 })) || [],
  });
});

app.post(['/api/sessions/:chunkId/correct', '/sessions/:chunkId/correct'], (req, res) => {
  const { chunkId } = req.params;
  const { intent } = req.body;
  const user = getAuthenticatedUser(req) || getDefaultUser();
  const sessions = getUserSessions(user.id);
  const chunk = sessions.find((s) => s.chunk_id === chunkId);
  if (!chunk) {
    return res.status(404).json({ error: 'Session chunk not found' });
  }

  chunk.intent = intent;
  chunk.user_corrected = true;
  saveUserSessions(user.id, sessions);
  res.json({ success: true, chunk });
});

// -------------------------------------------------------------
// AI ASSISTANT CHAT ENDPOINT (Context Grounded in Real User Activity)
// -------------------------------------------------------------

app.post('/api/assistant/chat', async (req, res) => {
  try {
    const { message, conversationHistory = [] } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    const user = getAuthenticatedUser(req) || getDefaultUser();
    const summary = getUserSummary(user.id);
    const sessions = getUserSessions(user.id);
    const telemetry = getUserTelemetry(user.id);
    const rec = getUserDeviceRecord(user.id);

    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: 'GEMINI_API_KEY not configured' });
    }

    const todayDate = rec.lastLocalDate || new Date().toISOString().split('T')[0];

    const systemPrompt = `You are ChronoTrace Assistant, a private, intelligent activity reconstruction assistant created with Google-level simplicity, clarity, and precision.
You answer user questions strictly based on their real, captured computer activity from the ChronoTrace Windows Agent today (${todayDate}).
User Name: ${user.name} (${user.username}).

REAL USER DATA TODAY:
1. Daily Synthesis Summary:
${JSON.stringify(summary, null, 2)}

2. Reconstructed Activity Timeline (Cognitive Chunks):
${JSON.stringify(sessions.slice(-15), null, 2)}

3. Recent Telemetry Window Switches:
${JSON.stringify(telemetry.slice(-20), null, 2)}

GUIDELINES:
- Base your answers ONLY on this user's captured telemetry and cognitive sessions.
- Accurately mention specific application names, window titles, exact durations in minutes/seconds, and intent categories.
- Respect their device's local date (${todayDate}) and timestamps.
- Be concise, direct, helpful, and objective.`;

    const contents: any[] = [{ role: 'user', parts: [{ text: systemPrompt }] }];

    if (Array.isArray(conversationHistory)) {
      for (const msg of conversationHistory) {
        if (msg.role === 'user' || msg.role === 'assistant') {
          contents.push({
            role: msg.role === 'user' ? 'user' : 'model',
            parts: [{ text: msg.content }],
          });
        }
      }
    }

    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
    });

    const answer = response.text || 'I analyzed your activity stream.';
    res.json({
      role: 'assistant',
      content: answer,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    });
  } catch (error: any) {
    console.error('Assistant error:', error);
    res.status(500).json({ error: error.message || 'Error generating assistant response' });
  }
});

app.post('/api/gemini/synthesize-day', async (req, res) => {
  try {
    const user = getAuthenticatedUser(req) || getDefaultUser();
    const sessions = req.body.sessions || getUserSessions(user.id);
    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: 'GEMINI_API_KEY not configured' });
    }

    const promptText = `Synthesize full-day cognitive activity from these session chunks:
${JSON.stringify(sessions, null, 2)}

Provide strict JSON output:
- total_deep_work_s: int
- total_distraction_s: int
- fragmentation_score: float 0-10
- peak_focus_window: string
- context_switches: int
- distraction_triggers: array of strings
- daily_narrative: 2-3 sentences narrative
- unfinished_work: array of strings`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    const currentSummary = getUserSummary(user.id);
    const updated = { ...currentSummary, ...parsed };
    saveUserSummary(user.id, updated);
    res.json(updated);
  } catch (error: any) {
    console.error('Gemini day synthesis error:', error);
    res.status(500).json({ error: error.message || 'Gemini error' });
  }
});

// -------------------------------------------------------------
// VITE SPA INTEGRATION
// -------------------------------------------------------------
async function startServer() {
  if (!IS_PRODUCTION) {
    // Development: Vite runs inside Express (middleware mode) and serves frontend/.
    const { createServer } = await import('vite');
    const vite = await createServer({
      configFile: path.resolve(ROOT, 'frontend/vite.config.ts'),
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production: serve the prebuilt React app from /dist (run `npm run build` first).
    const distPath = path.resolve(ROOT, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`ChronoTrace Full-Stack Server running on port ${PORT}`);
    console.log(`  ➜  Local:   http://localhost:${PORT}/`);
    console.log(`  ➜  Network: http://0.0.0.0:${PORT}/`);
  });
}

startServer();
