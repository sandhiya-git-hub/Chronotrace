/**
 * ChronoTrace Type Definitions
 */

export type IntentLabel =
  | 'DEEP_WORK'
  | 'LEARNING'
  | 'DISTRACTION'
  | 'DISTRACTION_BREAK'
  | 'COMMUNICATION'
  | 'AMBIENT'
  | 'ADMIN'
  | 'RESTLESS_START'
  | 'PARSE_ERROR';

export type MicroPattern = 'RESTLESS' | 'TAB_HUNTING' | 'SWITCHING' | 'NORMAL';

export interface TelemetryEvent {
  id?: string;
  timestamp: string;
  date?: string;
  recorded_at?: string; // ISO time the server recorded this event
  dwell_ms: number;
  category: string;
  app_name: string;
  window_title: string;
  keyboard_events: number;
}

export interface MicroCountersState {
  rapid_switches: number;
  unique_apps: string[];
  tab_flickers: number;
  total_dwell_ms: number;
  avg_dwell_ms: number;
  pattern: MicroPattern;
  events_count: number;
}

export interface MainEventSummary {
  app: string;
  title: string;
  dwell_s: number;
  keys: number;
}

export interface ChunkSummary {
  chunk_id: string;
  recorded_at?: string; // ISO time the session was first recorded
  duration_s: number;
  start_time: string;
  end_time: string;
  closed_by: string;
  main_events: MainEventSummary[];
  anchor_app: string | null;
  anchor_held_s: number;
  returned_to_anchor: boolean;
  keyboard: {
    total_keys: number;
    rate_per_min: number;
  };
  micro_behavior: {
    total_rapid_switches: number;
    tab_flickers: number;
    avg_micro_dwell_ms: number;
    dominant_pattern: MicroPattern;
    unique_micro_apps: string[];
  };
  categories_present: string[];
  dominant_category: string;
  copy_paste_events: number;
  session_start_restless: boolean;
  // LLM Classification enrichment
  intent?: IntentLabel;
  confidence?: number;
  primary_task?: string;
  distraction_detected?: boolean;
  distraction_type?: 'procrastination' | 'rabbit_hole' | 'social' | 'break' | null;
  work_state?: 'settled' | 'unsettled' | 'interrupted' | 'productive';
  pre_distraction_signal?: string | null;
  summary?: string;
  unresolved_threads?: string[];
  user_corrected?: boolean;
}

export interface DailySynthesis {
  date: string;
  range?: string;
  work_state?: 'settled' | 'unsettled' | 'interrupted' | 'productive' | 'UNSETTLED' | 'PRODUCTIVE' | 'TRANSITIONING' | 'BALANCED';
  total_deep_work_s: number;
  total_distraction_s: number;
  total_telemetry_s?: number;
  fragmentation_score: number;
  peak_focus_window: string;
  context_switches: number;
  distraction_triggers: string[];
  daily_narrative: string;
  unfinished_work: string[];
  stat_sub?: any;
  in_progress?: boolean;
}

export interface ReentryBriefing {
  project: string;
  found: boolean;
  days_ago?: number;
  time_desc?: string;
  headline: string;
  primary_task?: string;
  summary?: string;
  unresolved_threads: string[];
  last_session?: ChunkSummary;
}

export interface UserProfile {
  id: string;
  username?: string;
  email: string;
  name: string;
  picture?: string;
  givenName?: string;
  deviceToken?: string;
  emailVerified?: boolean;
  lastLogin?: string;
  isRegistered?: boolean;
  hasConfiguredDevice?: boolean;
}

export interface AuthState {
  authenticated: boolean;
  user: UserProfile | null;
  isRegistered?: boolean;
}

export interface DeviceState {
  // Derived by the server from the agent's heartbeat. Never assumed by the UI.
  connected: boolean;
  status?: 'CONNECTED' | 'CONNECTING' | 'DISCONNECTED' | 'NOT_CONNECTED' | 'FAILED';
  paused?: boolean;
  deviceName: string;
  os: string;
  agentVersion: string;
  lastEventTime: string | null;
  lastLocalDate?: string | null;
  eventCount: number;
  samplingInterval: string;
  statusText: string;
  lastPing?: string | null;
  lastHeartbeatAt?: string | null;
  connectedSince?: string | null;
  lastSuccessfulConnectionAt?: string | null;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  suggestedFollowUps?: string[];
  relatedSessions?: string[];
}

export type PrimaryNavTab = 'dashboard' | 'timeline' | 'raw' | 'assistant';
export type AppScreen = 'splash' | 'auth' | 'device' | 'app';
