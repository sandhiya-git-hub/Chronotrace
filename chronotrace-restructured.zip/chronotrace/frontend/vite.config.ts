import path from 'path';
import { fileURLToPath } from 'url';
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Vite serves the React app from /frontend. The Express server (backend/server.ts)
// mounts this config in dev, and serves the built /dist folder in production.
export default defineConfig({
  root: path.resolve(ROOT, 'frontend'),
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@shared': path.resolve(ROOT, 'shared'),
    },
  },
  build: {
    outDir: path.resolve(ROOT, 'dist'),
    emptyOutDir: true,
  },
  server: {
    // HMR can be turned off with DISABLE_HMR=true (same behaviour as before).
    hmr: process.env.DISABLE_HMR !== 'true',
  },
});
