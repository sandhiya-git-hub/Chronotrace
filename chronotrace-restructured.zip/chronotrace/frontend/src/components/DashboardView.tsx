import React, { useState, useEffect, useMemo } from 'react';
import { DateRangePicker, DateRangeSelection } from './DateRangePicker';
import {
  DailySynthesis,
  ChunkSummary,
  ReentryBriefing,
  UserProfile,
  TelemetryEvent,
} from '@shared/types/chronotrace';

interface DashboardViewProps {
  user: UserProfile | null;
  summary: DailySynthesis | null;
  chunks: ChunkSummary[];
  events?: TelemetryEvent[];
  reentry: ReentryBriefing | null;
  onRefreshSummary?: () => void;
  isSynthesizing?: boolean;
  onNavigateToTimeline?: () => void;
  onNavigateToAssistant?: (prompt?: string) => void;
}

// Heatmap data: 7 days x 24 hours
const heatmapData = [
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0.2, 0.8, 0.9, 0.7, 0.3, 0.5, 0.6, 0.9, 0.7, 0.3, 0.1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0.4, 0.6, 0.5, 0.8, 0.9, 0.7, 0.4, 0.6, 0.5, 0.2, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0.1, 0.3, 0.5, 0.7, 0.9, 0.8, 0.6, 0.7, 0.5, 0.3, 0.1, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0.2, 0.4, 0.3, 0.5, 0.4, 0.3, 0.2, 0.1, 0.2, 0.1, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.1, 0.2, 0.2, 0.1, 0.2, 0.1, 0.3, 0.2, 0.1, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
];

// Weekly bar data
const weeklyDays = [
  { day: 'Mon', deep: 180, dist: 45 },
  { day: 'Tue', deep: 240, dist: 60 },
  { day: 'Wed', deep: 120, dist: 90 },
  { day: 'Thu', deep: 60, dist: 120 },
  { day: 'Fri', deep: 27, dist: 258 },
  { day: 'Sat', deep: 0, dist: 0 },
  { day: 'Sun', deep: 0, dist: 0 },
];

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  summary: initialSummary,
  chunks = [],
  events = [],
  reentry,
  onRefreshSummary,
  isSynthesizing,
  onNavigateToTimeline,
  onNavigateToAssistant,
}) => {
  const [hoveredEvent, setHoveredEvent] = useState<string | null>(null);

  // Filter out obsolete dummy seed entries when real device activities are captured
  const displayEvents = useMemo(() => {
    if (!events || events.length === 0) return [];
    const hasLive = events.some(
      (e) => e.timestamp !== '18:52:14' && !e.window_title?.includes('Switch Case - YouTube')
    );
    if (hasLive) {
      return events.filter(
        (e) => e.timestamp !== '18:52:14' && !e.window_title?.includes('Switch Case - YouTube')
      );
    }
    return events;
  }, [events]);

  const totalDwell = useMemo(() => {
    return displayEvents.reduce((acc, e) => acc + (e.dwell_ms || 2000), 0);
  }, [displayEvents]);

  // Real current date from live events, server synthesis, or browser locale
  const initialDateStr = useMemo(() => {
    if (initialSummary?.date) return initialSummary.date;
    if (displayEvents.length > 0) {
      const last = displayEvents[displayEvents.length - 1];
      if (last.date) return last.date;
      if (last.recorded_at) return new Date(last.recorded_at).toLocaleDateString('en-CA');
    }
    return new Date().toLocaleDateString('en-CA');
  }, [initialSummary, displayEvents]);

  const [dateRange, setDateRange] = useState<DateRangeSelection>({
    type: 'today',
    label: 'Today',
    startDate: initialDateStr,
    endDate: initialDateStr,
  });

  const [activeSummary, setActiveSummary] = useState<any>(initialSummary);
  const [isFetching, setIsFetching] = useState<boolean>(false);

  // Sync initial summary if provided
  useEffect(() => {
    if (initialSummary && dateRange.type === 'today') {
      setActiveSummary(initialSummary);
    }
  }, [initialSummary]);

  // Keep date aligned with actual event dates
  useEffect(() => {
    if (initialDateStr && dateRange.type === 'today') {
      setDateRange((prev) => ({
        ...prev,
        startDate: initialDateStr,
        endDate: initialDateStr,
      }));
    }
  }, [initialDateStr]);

  // Fetch summary data whenever date range changes
  const handleDateRangeChange = async (newRange: DateRangeSelection) => {
    setDateRange(newRange);
    setIsFetching(true);
    try {
      const params = new URLSearchParams({
        range: newRange.type,
        ...(newRange.startDate && { startDate: newRange.startDate }),
        ...(newRange.endDate && { endDate: newRange.endDate }),
      });
      const res = await fetch(`/api/summary?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setActiveSummary(data);
      }
    } catch (err) {
      console.error('Error fetching summary for range:', err);
    } finally {
      setIsFetching(false);
    }
  };

  const getSegmentColor = (cat: string) => {
    switch (cat) {
      case 'Deep Work':
        return '#334155'; // dark slate
      case 'Learning':
        return '#22c55e'; // green
      case 'Distraction':
        return '#ef4444'; // red
      case 'Ambient':
        return '#3b82f6'; // blue
      case 'Restless':
        return '#f59e0b'; // amber
      case 'Break':
        return '#06b6d4'; // cyan
      default:
        return '#64748b';
    }
  };

  // Format seconds into human readable text (e.g. 39s, 3m 12s, 13m 49s)
  const formatSec = (seconds: number = 0) => {
    if (seconds <= 0) return '0s';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins > 0 && secs > 0) return `${mins}m ${secs}s`;
    if (mins > 0) return `${mins}m`;
    return `${secs}s`;
  };

  const deepWorkSec = activeSummary?.total_deep_work_s ?? 0;
  const distractionSec = activeSummary?.total_distraction_s ?? 0;
  const switches = activeSummary?.context_switches ?? 0;
  const totalSec = activeSummary?.total_telemetry_s ?? (deepWorkSec + distractionSec);
  const workState = activeSummary?.work_state || (distractionSec > deepWorkSec ? 'UNSETTLED' : 'PRODUCTIVE');

  // Subtitles from backend or dynamically generated from real event counts
  const deepSub = activeSummary?.stat_sub?.deep_work || (deepWorkSec > 0 ? `— ${formatSec(deepWorkSec)} focused work & research` : 'No deep work recorded yet');
  const distSub = activeSummary?.stat_sub?.distraction || (distractionSec > 0 ? `↓ ${formatSec(distractionSec)} distraction dwell` : '0s recorded distraction');
  const switchSub = activeSummary?.stat_sub?.context_switches || (switches > 0 ? `— ${switches} window transitions detected` : '— Active telemetry stream');
  const workStateSub = activeSummary?.stat_sub?.work_state || (
    totalSec === 0
      ? 'Waiting for Windows agent activity'
      : workState === 'PRODUCTIVE'
      ? `↑ Deep Work (${formatSec(deepWorkSec)}) > Distraction (${formatSec(distractionSec)}) · Sustained flow`
      : `↓ Distraction (${formatSec(distractionSec)}) > Deep Work (${formatSec(deepWorkSec)}) · High fragmentation`
  );

  return (
    <div className="space-y-4 pb-12 font-sans text-slate-800">
      {/* ─── TOP BAR WITH DATE RANGE PICKER ─── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-1">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-none">
            Analytics Overview
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time passive telemetry reconstruction &amp; cognitive behavior stream
          </p>
        </div>

        {/* User-friendly Date Range Picker */}
        <div className="flex items-center gap-2">
          <DateRangePicker
            value={dateRange}
            onChange={handleDateRangeChange}
            isLoading={isFetching}
          />
        </div>
      </div>

      {/* ─── 1. TOP STAT ROW (GRID 4) ─── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Sustained Deep Work */}
        <div className={`bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Sustained Deep Work</div>
          <div className="text-3xl font-bold text-blue-600 mt-1 tracking-tight font-sans">
            {formatSec(deepWorkSec)}
          </div>
          <div className="text-xs text-slate-400 mt-1.5 flex items-center gap-1 font-normal truncate" title={deepSub}>
            <span>{deepSub}</span>
          </div>
        </div>

        {/* Card 2: Distraction Time */}
        <div className={`bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Distraction Time</div>
          <div className="text-3xl font-bold text-red-600 mt-1 tracking-tight font-sans">
            {formatSec(distractionSec)}
          </div>
          <div className="text-xs text-red-600/90 mt-1.5 flex items-center gap-1 font-normal truncate" title={distSub}>
            <span>{distSub}</span>
          </div>
        </div>

        {/* Card 3: Context Switches */}
        <div className={`bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Context Switches</div>
          <div className="text-3xl font-bold text-amber-600 mt-1 tracking-tight font-sans">
            {switches}
          </div>
          <div className="text-xs text-slate-400 mt-1.5 flex items-center gap-1 font-normal truncate" title={switchSub}>
            <span>{switchSub}</span>
          </div>
        </div>

        {/* Card 4: Work State */}
        <div className={`bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Work State</div>
          <div className={`text-3xl font-bold mt-1 tracking-tight font-sans uppercase ${workState === 'PRODUCTIVE' ? 'text-emerald-600' : 'text-amber-600'}`}>
            {workState}
          </div>
          <div className={`text-xs mt-1.5 flex items-center gap-1 font-normal truncate ${workState === 'PRODUCTIVE' ? 'text-emerald-700' : 'text-red-600/90'}`} title={workStateSub}>
            <span>{workStateSub}</span>
          </div>
        </div>
      </div>

      {/* ─── 2. ROW 2: TIMELINE + DONUT (GRID 2:1) ─── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left (2 spans): Today's Activity Timeline + Hourly Focus Heatmap */}
        <div className="lg:col-span-2 bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-slate-900">Today&apos;s Activity Timeline</h2>
              <span className="text-xs text-slate-700 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded font-mono font-medium">
                {displayEvents.length > 0
                  ? `${displayEvents[0].timestamp} → ${displayEvents[displayEvents.length - 1].timestamp}`
                  : 'Waiting for stream'}
              </span>
            </div>

            {/* Segmented Timeline Bar */}
            <div className="relative">
              {displayEvents.length === 0 ? (
                <div className="h-9 w-full rounded-md bg-slate-100 border border-dashed border-slate-300 flex items-center justify-center text-xs text-slate-500">
                  Waiting for live activity from device...
                </div>
              ) : (
                <div className="h-9 w-full rounded-md overflow-hidden flex gap-[2px] bg-slate-100 p-0.5">
                  {displayEvents.map((evt, idx) => {
                    const dwell = evt.dwell_ms || 2000;
                    const pct = totalDwell > 0 ? (dwell / totalDwell) * 100 : 100 / displayEvents.length;
                    const bg = getSegmentColor(evt.category);
                    const dwellSec = Math.round(dwell / 1000);
                    return (
                      <div
                        key={idx}
                        onMouseEnter={() =>
                          setHoveredEvent(
                            `${evt.app_name}: ${evt.window_title} (${dwellSec}s · ${evt.timestamp})`
                          )
                        }
                        onMouseLeave={() => setHoveredEvent(null)}
                        style={{
                          width: `${Math.max(pct, 0.6)}%`,
                          backgroundColor: bg,
                        }}
                        className="h-full rounded-[2px] cursor-pointer hover:opacity-85 transition-opacity"
                        title={`${evt.app_name}: ${evt.window_title} (${dwellSec}s · ${evt.timestamp})`}
                      />
                    );
                  })}
                </div>
              )}

              {hoveredEvent && (
                <div className="absolute -top-7 left-2 bg-slate-900 text-white text-[11px] px-2 py-0.5 rounded shadow z-10 pointer-events-none truncate max-w-md">
                  {hoveredEvent}
                </div>
              )}
            </div>

            {/* Legend */}
            <div className="flex flex-wrap items-center gap-3.5 mt-3 text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#334155]" />
                <span>Deep Work</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#22c55e]" />
                <span>Learning</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#ef4444]" />
                <span>Distraction</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#3b82f6]" />
                <span>Ambient</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#f59e0b]" />
                <span>Restless</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#06b6d4]" />
                <span>Utility</span>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100">
            <h3 className="text-xs font-semibold text-slate-900 mb-2">Hourly Focus Heatmap (This Week)</h3>
            <div className="space-y-1">
              {heatmapData.map((dayRow, rIdx) => (
                <div key={rIdx} className="grid grid-cols-24 gap-[3px]">
                  {dayRow.map((val, cIdx) => {
                    const isZero = val === 0;
                    return (
                      <div
                        key={cIdx}
                        className="h-5 rounded-[2px] transition-colors"
                        style={{
                          backgroundColor: isZero
                            ? '#e2e8f0'
                            : `rgba(37, 99, 235, ${Math.min(val * 0.9 + 0.1, 1)})`,
                        }}
                        title={`Hour ${cIdx}: ${Math.round(val * 100)}% focus`}
                      />
                    );
                  })}
                </div>
              ))}
            </div>

            <div className="flex justify-between text-[10px] text-slate-400 mt-1.5 px-0.5">
              <span>12 AM</span>
              <span>6 AM</span>
              <span>12 PM</span>
              <span>6 PM</span>
              <span>11 PM</span>
            </div>
          </div>
        </div>

        {/* Right (1 span): Session Intent Breakdown Donut + Micro-Behavior Patterns */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
              SESSION INTENT BREAKDOWN
            </div>

            {/* SVG Donut Chart */}
            {(() => {
              let deepSec = 0;
              let learnSec = 0;
              let distSec = 0;
              let utilitySec = 0;
              let commSec = 0;

              displayEvents.forEach((e) => {
                const sec = Math.round((e.dwell_ms || 2000) / 1000);
                const cat = e.category || 'Utility';
                if (cat === 'Deep Work') deepSec += sec;
                else if (cat === 'Learning') learnSec += sec;
                else if (cat === 'Distraction' || cat === 'Entertainment') distSec += sec;
                else if (cat === 'Communication') commSec += sec;
                else utilitySec += sec;
              });

              const total = deepSec + learnSec + distSec + utilitySec + commSec || 1;
              const C = 213.63;
              const pDist = distSec / total;
              const pDeep = deepSec / total;
              const pLearn = learnSec / total;
              const pUtil = utilitySec / total;
              const pComm = commSec / total;

              const pctDist = Math.round(pDist * 100);
              const pctDeep = Math.round(pDeep * 100);
              const pctLearn = Math.round(pLearn * 100);
              const pctUtil = Math.round(pUtil * 100);
              const pctComm = Math.round(pComm * 100);

              return (
                <div className="flex flex-col items-center justify-center my-2">
                  <div className="relative w-36 h-36">
                    <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                      {/* Deep Work */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#2563eb"
                        strokeWidth="18"
                        strokeDasharray={`${(pDeep * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset="0"
                      />
                      {/* Learning */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#16a34a"
                        strokeWidth="18"
                        strokeDasharray={`${(pLearn * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-(pDeep * C)}`}
                      />
                      {/* Distraction */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#dc2626"
                        strokeWidth="18"
                        strokeDasharray={`${(pDist * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-((pDeep + pLearn) * C)}`}
                      />
                      {/* Utility */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#64748b"
                        strokeWidth="18"
                        strokeDasharray={`${(pUtil * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-((pDeep + pLearn + pDist) * C)}`}
                      />
                      {/* Communication */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#8b5cf6"
                        strokeWidth="18"
                        strokeDasharray={`${(pComm * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-((pDeep + pLearn + pDist + pUtil) * C)}`}
                      />
                    </svg>
                  </div>

                  {/* Donut Legend with Real Percentages */}
                  <div className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-1 mt-2 text-[10px] text-slate-600">
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-[2px] bg-[#2563eb]" />
                      <span>Deep Work {pctDeep}%</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-[2px] bg-[#16a34a]" />
                      <span>Learning {pctLearn}%</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-[2px] bg-[#dc2626]" />
                      <span>Distraction {pctDist}%</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-[2px] bg-[#64748b]" />
                      <span>Utility {pctUtil}%</span>
                    </span>
                    {pctComm > 0 && (
                      <span className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-[2px] bg-[#8b5cf6]" />
                        <span>Social {pctComm}%</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Micro-Behavior Patterns from Live Session Data */}
          <div className="mt-4 pt-4 border-t border-slate-100">
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-3">
              MICRO-BEHAVIOR PATTERNS
            </div>

            {(() => {
              const rapidSwitches = activeSummary?.context_switches ?? Math.max(0, displayEvents.length - 1);
              const tabFlickers = displayEvents.filter((e) => (e.dwell_ms || 2000) <= 3000).length;
              const avgDwellSec = displayEvents.length > 0 ? (totalDwell / displayEvents.length / 1000).toFixed(1) + 's' : '0s';
              const restlessCount = chunks.filter(
                (c) => c.session_start_restless || c.micro_behavior?.dominant_pattern === 'RESTLESS'
              ).length;

              return (
                <div className="space-y-2.5 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Rapid Switches</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600 rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(8, rapidSwitches * 3))}%` }}
                      />
                    </div>
                    <span className="text-blue-600 font-semibold w-7 text-right text-xs">
                      {rapidSwitches}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Tab Flickers</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500 rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(8, tabFlickers * 5))}%` }}
                      />
                    </div>
                    <span className="text-amber-600 font-semibold w-7 text-right text-xs">
                      {tabFlickers}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Avg Micro Dwell</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-600 rounded-full w-[45%]" />
                    </div>
                    <span className="text-slate-600 font-semibold w-7 text-right text-xs">
                      {avgDwellSec}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Active Sessions</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-purple-600 rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(10, chunks.length * 8))}%` }}
                      />
                    </div>
                    <span className="text-purple-600 font-semibold w-7 text-right text-xs">
                      {chunks.length}
                    </span>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      {/* ─── 3. ROW 3: 7-DAY FOCUS VS DISTRACTION + DISTRACTION TRIGGERS (GRID 2) ─── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left: 7-Day Focus vs Distraction Stacked Bar Chart */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              7-DAY FOCUS VS DISTRACTION
            </h2>
            <div className="flex items-center gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-blue-600" />
                <span>Deep Work</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-red-500" />
                <span>Distraction</span>
              </div>
            </div>
          </div>

          {/* Stacked Bar Chart with Grid Lines */}
          <div className="h-52 relative flex flex-col justify-between pt-2">
            {/* Background Grid Lines */}
            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none text-[10px] text-slate-400 pl-7">
              <div className="border-b border-slate-100 flex items-center justify-between">
                <span>300</span>
              </div>
              <div className="border-b border-slate-100 flex items-center justify-between">
                <span>250</span>
              </div>
              <div className="border-b border-slate-100 flex items-center justify-between">
                <span>200</span>
              </div>
              <div className="border-b border-slate-100 flex items-center justify-between">
                <span>150</span>
              </div>
              <div className="border-b border-slate-100 flex items-center justify-between">
                <span>100</span>
              </div>
              <div className="border-b border-slate-100 flex items-center justify-between">
                <span>50</span>
              </div>
              <div className="border-b border-slate-200 flex items-center justify-between">
                <span>0</span>
              </div>
            </div>

            {/* Bars Column Container */}
            <div className="relative h-44 ml-8 flex items-end justify-between px-3">
              {weeklyDays.map((item, idx) => {
                const maxVal = 300;
                const deepH = (item.deep / maxVal) * 100;
                const distH = (item.dist / maxVal) * 100;
                return (
                  <div key={idx} className="flex flex-col items-center w-8">
                    <div className="w-7 flex flex-col justify-end" style={{ height: '160px' }}>
                      {/* Distraction top bar */}
                      {item.dist > 0 && (
                        <div
                          style={{ height: `${distH}%` }}
                          className="w-full bg-red-500 rounded-t-[3px] transition-all"
                          title={`${item.day} Distraction: ${item.dist}m`}
                        />
                      )}
                      {/* Deep work bottom bar */}
                      {item.deep > 0 && (
                        <div
                          style={{ height: `${deepH}%` }}
                          className={`w-full bg-blue-600 transition-all ${
                            item.dist === 0 ? 'rounded-t-[3px]' : ''
                          }`}
                          title={`${item.day} Deep Work: ${item.deep}m`}
                        />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* X-axis Labels */}
            <div className="ml-8 flex justify-between px-3 text-[11px] text-slate-500 pt-1 border-t border-slate-200">
              {weeklyDays.map((d, i) => (
                <span key={i} className="w-8 text-center">
                  {d.day}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Distraction Triggers (by dwell time) */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-4">
            DISTRACTION TRIGGERS (BY DWELL TIME)
          </div>

          <div className="space-y-4 pt-1">
            {(() => {
              const triggerMap = new Map<string, number>();
              displayEvents.forEach((e) => {
                if (e.category === 'Distraction' || e.category === 'Entertainment') {
                  const title = e.window_title || e.app_name || 'Media';
                  triggerMap.set(title, (triggerMap.get(title) || 0) + Math.round((e.dwell_ms || 2000) / 1000));
                }
              });
              const triggers = Array.from(triggerMap.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5);

              if (triggers.length === 0) {
                return (
                  <div className="py-8 text-center text-xs text-slate-500">
                    <p className="font-semibold text-emerald-700">0s recorded distraction</p>
                    <p className="text-[11px] text-slate-400 mt-1">High focus sustained across your active desktop applications.</p>
                  </div>
                );
              }

              const maxDwell = triggers[0][1] || 1;
              const barColors = ['bg-red-600', 'bg-amber-600', 'bg-purple-600', 'bg-rose-500', 'bg-blue-600'];

              return triggers.map(([name, dwellSec], idx) => (
                <div key={idx} className="flex items-center gap-3 text-xs">
                  <span className="w-44 text-slate-700 truncate font-medium" title={name}>
                    {name}
                  </span>
                  <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${barColors[idx % barColors.length]} rounded-full transition-all`}
                      style={{ width: `${Math.min(100, Math.max(10, Math.round((dwellSec / maxDwell) * 100)))}%` }}
                    />
                  </div>
                  <span className="w-12 text-right text-slate-500 font-mono text-[11px]">
                    {dwellSec}s
                  </span>
                </div>
              ));
            })()}
          </div>
        </div>
      </div>

      {/* ─── 4. ROW 4: DETECTED ANOMALIES + SESSION QUALITY SCORES (GRID 2) ─── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left: ⚡ Detected Anomalies & Insights */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-amber-600 flex items-center gap-1.5 mb-3">
            <span>⚡ DETECTED BEHAVIOR &amp; INSIGHTS</span>
          </div>

          <div className="space-y-2.5">
            {/* Behavior 1 */}
            <div className="p-3 rounded-lg bg-blue-50/70 border border-blue-100 flex items-start gap-3">
              <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0 mt-0.5 text-sm">
                💻
              </div>
              <div>
                <h4 className="text-xs font-semibold text-slate-900 leading-tight">
                  Active foreground workstation flow
                </h4>
                <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                  {activeSummary?.daily_narrative ||
                    `Captured ${displayEvents.length} continuous activity intervals. Monitored foreground switches and verified application dwell time.`}
                </p>
              </div>
            </div>

            {/* Behavior 2 */}
            <div className="p-3 rounded-lg bg-emerald-50/60 border border-emerald-100 flex items-start gap-3">
              <div className="w-7 h-7 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5 text-sm">
                🎯
              </div>
              <div>
                <h4 className="text-xs font-semibold text-slate-900 leading-tight">
                  Cognitive Session Reconstruction
                </h4>
                <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                  Grouped rapid window transitions into {chunks.length} structured work sessions with automated intent classification.
                </p>
              </div>
            </div>

            {/* Behavior 3 */}
            <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex items-start gap-3">
              <div className="w-7 h-7 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center shrink-0 mt-0.5 text-sm">
                🛡️
              </div>
              <div>
                <h4 className="text-xs font-semibold text-slate-900 leading-tight">
                  Privacy-first zero payload tracking
                </h4>
                <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                  Only window titles and duration seconds are transmitted. Keystroke content, browser cookies, and screens remain 100% private.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Session Quality Scores + Context Switch Heatmap */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-3">
              SESSION QUALITY SCORES
            </div>

            {/* 3 Circular Progress Rings */}
            <div className="flex justify-around items-center my-2">
              {/* Ring 1: Focus Score (1.2 / Red) */}
              <div className="flex flex-col items-center">
                <div className="relative w-20 h-20">
                  <svg viewBox="0 0 90 90" className="w-full h-full -rotate-90">
                    <circle cx="45" cy="45" r="35" fill="none" stroke="#e2e8f0" strokeWidth="8" />
                    <circle
                      cx="45"
                      cy="45"
                      r="35"
                      fill="none"
                      stroke="#dc2626"
                      strokeWidth="8"
                      strokeDasharray="26 194"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center text-lg font-bold text-red-600 font-sans">
                    1.2
                  </div>
                </div>
                <div className="text-[11px] text-slate-500 text-center mt-1 leading-tight font-medium">
                  Focus<br />Score
                </div>
              </div>

              {/* Ring 2: Fragmentation Resistance (2.2 / Amber) */}
              <div className="flex flex-col items-center">
                <div className="relative w-20 h-20">
                  <svg viewBox="0 0 90 90" className="w-full h-full -rotate-90">
                    <circle cx="45" cy="45" r="35" fill="none" stroke="#e2e8f0" strokeWidth="8" />
                    <circle
                      cx="45"
                      cy="45"
                      r="35"
                      fill="none"
                      stroke="#d97706"
                      strokeWidth="8"
                      strokeDasharray="47 173"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center text-lg font-bold text-amber-600 font-sans">
                    2.2
                  </div>
                </div>
                <div className="text-[11px] text-slate-500 text-center mt-1 leading-tight font-medium">
                  Fragmentation<br />Resistance
                </div>
              </div>

              {/* Ring 3: Self-Awareness Index (4.1 / Green) */}
              <div className="flex flex-col items-center">
                <div className="relative w-20 h-20">
                  <svg viewBox="0 0 90 90" className="w-full h-full -rotate-90">
                    <circle cx="45" cy="45" r="35" fill="none" stroke="#e2e8f0" strokeWidth="8" />
                    <circle
                      cx="45"
                      cy="45"
                      r="35"
                      fill="none"
                      stroke="#16a34a"
                      strokeWidth="8"
                      strokeDasharray="88 132"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center text-lg font-bold text-emerald-600 font-sans">
                    4.1
                  </div>
                </div>
                <div className="text-[11px] text-slate-500 text-center mt-1 leading-tight font-medium">
                  Self-Awareness<br />Index
                </div>
              </div>
            </div>
          </div>

          {/* Context Switch Heatmap (Today) Line/Area Chart */}
          <div className="mt-4 pt-4 border-t border-slate-100">
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
              CONTEXT SWITCH HEATMAP (TODAY)
            </div>

            <div className="h-24 w-full relative">
              <svg viewBox="0 0 400 90" className="w-full h-full overflow-visible">
                {/* Y-axis gridlines */}
                <line x1="25" y1="10" x2="395" y2="10" stroke="#f1f5f9" strokeWidth="1" />
                <line x1="25" y1="30" x2="395" y2="30" stroke="#f1f5f9" strokeWidth="1" />
                <line x1="25" y1="50" x2="395" y2="50" stroke="#f1f5f9" strokeWidth="1" />
                <line x1="25" y1="70" x2="395" y2="70" stroke="#f1f5f9" strokeWidth="1" />

                {/* Y-axis labels */}
                <text x="12" y="14" fontSize="8" fill="#94a3b8">8</text>
                <text x="12" y="34" fontSize="8" fill="#94a3b8">6</text>
                <text x="12" y="54" fontSize="8" fill="#94a3b8">4</text>
                <text x="12" y="74" fontSize="8" fill="#94a3b8">2</text>
                <text x="12" y="88" fontSize="8" fill="#94a3b8">0</text>

                <defs>
                  <linearGradient id="switchGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#d97706" stopOpacity="0.25" />
                    <stop offset="100%" stopColor="#d97706" stopOpacity="0.02" />
                  </linearGradient>
                </defs>

                <path
                  d="M 35 62 C 65 67, 75 70, 95 70 C 125 70, 135 52, 155 52 C 185 52, 195 20, 215 20 C 245 20, 255 70, 275 70 C 305 70, 315 88, 335 88 C 365 88, 375 79, 390 79 L 390 88 L 35 88 Z"
                  fill="url(#switchGradient)"
                />

                {/* Line curve */}
                <path
                  d="M 35 62 C 65 67, 75 70, 95 70 C 125 70, 135 52, 155 52 C 185 52, 195 20, 215 20 C 245 20, 255 70, 275 70 C 305 70, 315 88, 335 88 C 365 88, 375 79, 390 79"
                  fill="none"
                  stroke="#d97706"
                  strokeWidth="2.2"
                />

                {/* Points */}
                <circle cx="35" cy="62" r="3" fill="#d97706" />
                <circle cx="95" cy="70" r="3" fill="#d97706" />
                <circle cx="155" cy="52" r="3" fill="#d97706" />
                <circle cx="215" cy="20" r="3" fill="#d97706" />
                <circle cx="275" cy="70" r="3" fill="#d97706" />
                <circle cx="335" cy="88" r="3" fill="#d97706" />
                <circle cx="390" cy="79" r="3" fill="#d97706" />
              </svg>
            </div>

            {/* X-axis time marks */}
            <div className="flex justify-between text-[10px] text-slate-400 pl-6 pr-1 font-mono">
              <span>18:52</span>
              <span>18:53</span>
              <span>18:54</span>
              <span>18:55</span>
              <span>18:56</span>
              <span>18:57</span>
              <span>18:58</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
