import React, { useState, useEffect } from 'react';
import {
  Laptop,
  CheckCircle2,
  XCircle,
  Shield,
  ArrowRight,
  ArrowLeft,
  RefreshCw,
  Terminal,
  Check,
  Copy,
  Download,
  Radio,
  Zap,
  Activity,
} from 'lucide-react';
import { DeviceState, UserProfile } from '@shared/types/chronotrace';

interface DeviceSetupScreenProps {
  onComplete: () => void;
  onBack?: () => void;
  isRegisteredUser?: boolean;
  user?: UserProfile | null;
}

const formatDateTime = (iso?: string | null) => (iso ? new Date(iso).toLocaleString() : 'Never');

// Visible status used everywhere on this screen
const StatusBadge: React.FC<{ connected: boolean; status?: string; isConnecting?: boolean }> = ({ connected, status, isConnecting }) => {
  if (isConnecting) {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border bg-amber-50 border-amber-200 text-amber-800">
        <RefreshCw className="w-3 h-3 animate-spin" />
        Connecting...
      </span>
    );
  }
  if (connected || status === 'CONNECTED') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border bg-emerald-50 border-emerald-200 text-emerald-800">
        <CheckCircle2 className="w-3 h-3" />
        Connected
      </span>
    );
  }
  if (status === 'DISCONNECTED') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border bg-slate-100 border-slate-300 text-slate-700">
        <XCircle className="w-3 h-3 text-slate-500" />
        Disconnected
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border bg-rose-50 border-rose-200 text-rose-700">
      <XCircle className="w-3 h-3" />
      Not Connected
    </span>
  );
};

export const DeviceSetupScreen: React.FC<DeviceSetupScreenProps> = ({
  onComplete,
  onBack,
  isRegisteredUser = false,
  user,
}) => {
  const [deviceState, setDeviceState] = useState<DeviceState>({
    connected: false,
    deviceName: 'DESKTOP-WIN11-WORKSTATION',
    os: 'Windows 11 Pro 64-bit',
    agentVersion: '1.2.0',
    lastEventTime: null,
    eventCount: 0,
    samplingInterval: '500ms',
    statusText: 'Not Connected · Waiting for the Windows agent',
  });

  // Collection setting chosen by the user (ON/OFF). Live connection is shown separately.
  const collectionOn = deviceState.paused !== true;

  const [isToggling, setIsToggling] = useState<boolean>(false);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [copiedScriptCommand, setCopiedScriptCommand] = useState<boolean>(false);
  const [copiedOneLiner, setCopiedOneLiner] = useState<boolean>(false);
  const [verifyMessage, setVerifyMessage] = useState<string | null>(null);
  const [hostUrl, setHostUrl] = useState<string>('');
  const [downloadStarted, setDownloadStarted] = useState<boolean>(false);

  useEffect(() => {
    fetchDeviceStatus();
    if (typeof window !== 'undefined') {
      setHostUrl(window.location.origin);
    }

    // Poll so the badge follows the agent's heartbeat in near real time
    const pollInterval = setInterval(() => {
      fetchDeviceStatus();
    }, 2500);

    return () => clearInterval(pollInterval);
  }, []);

  // Always mirror the server's status. Never mark the device connected on the client.
  const fetchDeviceStatus = async () => {
    try {
      const res = await fetch('/api/device/status');
      if (res.ok) {
        const data: DeviceState = await res.json();
        setDeviceState(data);
      }
    } catch (e) {
      console.error('Error fetching device status:', e);
    }
  };

  // Toggle ON and OFF for already registered user
  const handleToggleReconstruction = async () => {
    const nextState = deviceState.paused === true; // paused -> turn collection on
    setIsToggling(true);
    try {
      const res = await fetch('/api/device/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ connected: nextState }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.device) {
          setDeviceState(data.device);
        } else {
          setDeviceState((prev) => ({
            ...prev,
            connected: nextState,
            statusText: nextState
              ? 'Connected · Productivity activity reconstruction active'
              : 'Disconnected · Productivity activity reconstruction paused',
          }));
        }
      }
    } catch (e) {
      console.error('Error toggling device reconstruction:', e);
    } finally {
      setIsToggling(false);
    }
  };

  // Verify Connection: asks the server whether the agent is heartbeating right now.
  // Success is only shown when the server reports Connected.
  const handleVerifyConnection = async () => {
    setIsConnecting(true);
    setVerifyMessage(null);
    try {
      const res = await fetch('/api/device/connect', { method: 'POST' });
      const data = await res.json();
      if (data.device) setDeviceState(data.device);
      setVerifyMessage(data.message || null);
      if (data.connected) {
        await fetch('/api/auth/complete-device-setup', { method: 'POST' });
      }
    } catch (e) {
      console.error('Verification error:', e);
      setVerifyMessage('Could not reach the ChronoTrace server. Check your connection and try again.');
    } finally {
      setIsConnecting(false);
    }
  };

  const appOrigin = hostUrl || (typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000');
  const tokenParam = user?.deviceToken ? `?token=${encodeURIComponent(user.deviceToken)}` : '';
  const tokenFlag = user?.deviceToken ? ` --token "${user.deviceToken}"` : '';

  // Run from the folder the script was downloaded to (Downloads by default).
  const runDownloadedScriptCommand = `cd "$env:USERPROFILE\\Downloads"; python chronotrace_agent.py "${appOrigin}"${tokenFlag}`;

  // Automated one-line PowerShell command (cleans up any old file, downloads fresh script with user token, and runs it)
  const oneLinerPowerShellCommand = `Remove-Item -Force chronotrace_agent.py -ErrorAction SilentlyContinue; Invoke-WebRequest -UseBasicParsing -Uri "${appOrigin}/api/download-agent${tokenParam}" -OutFile chronotrace_agent.py; python chronotrace_agent.py "${appOrigin}"${tokenFlag}`;

  const copyRunCommand = () => {
    navigator.clipboard.writeText(runDownloadedScriptCommand);
    setCopiedScriptCommand(true);
    setTimeout(() => setCopiedScriptCommand(false), 2000);
  };

  const copyOneLinerCommand = () => {
    navigator.clipboard.writeText(oneLinerPowerShellCommand);
    setCopiedOneLiner(true);
    setTimeout(() => setCopiedOneLiner(false), 2000);
  };

  const handleDownloadScript = async (e: React.MouseEvent) => {
    e.preventDefault();
    try {
      const res = await fetch(`/api/download-agent${tokenParam}`);
      if (!res.ok) throw new Error('Download failed');
      const text = await res.text();
      const blob = new Blob([text], { type: 'text/x-python' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'chronotrace_agent.py';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setDownloadStarted(true);
    } catch {
      window.location.href = `/api/download-agent${tokenParam}`;
      setDownloadStarted(true);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between items-center px-4 py-8 sm:py-12 selection:bg-blue-100 font-sans">
      {/* Header */}
      <header className="w-full max-w-2xl flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white text-sm font-semibold shadow-xs">
            C
          </div>
          <div>
            <span className="font-semibold text-slate-900 tracking-tight text-sm block">
              ChronoTrace
            </span>
            <span className="text-[11px] text-slate-500 font-normal">
              {isRegisteredUser ? 'Device Reconnection' : 'Device Connection Setup'}
            </span>
          </div>
        </div>

        {onBack && (
          <button
            type="button"
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
        )}
      </header>

      {/* Main Card */}
      <main className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-sm p-6 sm:p-9 my-6">
        {/* ============================================================== */}
        {/* CASE 1: ALREADY REGISTERED USER -> ON / OFF TOGGLE */}
        {/* ============================================================== */}
        {isRegisteredUser ? (
          <div className="space-y-6">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-[11px] font-medium mb-2.5">
                <span>Welcome back, {user?.name || user?.givenName || 'User'}</span>
              </div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                Device Connection
              </h2>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Connect again with the website for productivity activity reconstruction. Toggle ON or OFF anytime.
              </p>
            </div>

            {/* Workstation Card with Toggle */}
            <div
              className={`p-5 rounded-2xl border transition-all ${
                deviceState.connected
                  ? 'border-emerald-300 bg-emerald-50/40 shadow-xs'
                  : 'border-slate-200 bg-slate-50/70'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors shadow-2xs ${
                      deviceState.connected
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 text-slate-500'
                    }`}
                  >
                    <Laptop className="w-6 h-6 stroke-[1.9]" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-slate-900">
                        {deviceState.deviceName}
                      </span>
                      <StatusBadge connected={deviceState.connected} />
                    </div>
                    <div className="text-xs text-slate-500 mt-0.5">
                      {deviceState.os} · {deviceState.eventCount} telemetry events recorded
                    </div>
                  </div>
                </div>

                {/* ON / OFF Switch */}
                <div className="flex items-center gap-3 self-end sm:self-center">
                  <span
                    className={`text-xs font-semibold tracking-wide ${
                      collectionOn ? 'text-emerald-700' : 'text-slate-500'
                    }`}
                  >
                    {collectionOn ? 'ON' : 'OFF'}
                  </span>

                  <button
                    type="button"
                    onClick={handleToggleReconstruction}
                    disabled={isToggling}
                    className={`relative inline-flex h-7 w-14 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                      collectionOn ? 'bg-emerald-600' : 'bg-slate-300'
                    }`}
                    aria-label="Toggle device connection"
                  >
                    <span
                      className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                        collectionOn ? 'translate-x-7' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Status explanation */}
              <div className="mt-4 pt-3.5 border-t border-slate-200/70 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 text-slate-700">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      deviceState.connected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'
                    }`}
                  />
                  <span className="font-medium text-xs">
                    {deviceState.statusText}
                  </span>
                </div>
                <span className="text-[11px] text-slate-500">
                  Last successful connection: {formatDateTime(deviceState.lastSuccessfulConnectionAt)}
                </span>
              </div>
            </div>

            {/* Privacy note */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-600">
              <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                Protected local telemetry. Passive monitoring collects window titles and activity duration only. No passwords, camera, or screens are ever recorded.
              </span>
            </div>

            {/* Navigation to Dashboard: only available while the device is connected */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-end gap-3">
              {!deviceState.connected && (
                <span className="text-[11px] text-rose-700 sm:mr-auto">
                  Dashboard is locked until the device is connected.
                </span>
              )}
              <button
                type="button"
                onClick={onComplete}
                disabled={!deviceState.connected}
                className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-medium px-6 py-2.5 rounded-xl text-xs shadow-xs transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-blue-600"
              >
                <span>Continue to Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* ============================================================== */
          /* CASE 2: FIRST-TIME SETUP -> DOWNLOAD SCRIPT + POWERSHELL COMMAND */
          /* ============================================================== */
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                Connect Your Device
              </h2>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                Download the telemetry script and copy the command to run in PowerShell. Activity will collect continuously in PowerShell and stream to the website for passive activity reconstruction.
              </p>
            </div>

            {/* STEP 1: Download Script */}
            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/50 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
                    1
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900">
                      Download Telemetry Script
                    </h3>
                    <p className="text-[11px] text-slate-600">
                      Standard Python 3 script (Zero pip dependencies required)
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleDownloadScript}
                  className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-2xs transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Script (chronotrace_agent.py)</span>
                </button>
              </div>

              {downloadStarted && (
                <div className="flex items-center gap-2 text-[11px] text-emerald-700 font-medium bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>
                    Script downloaded! Move to Step 2 and run the PowerShell command.
                  </span>
                </div>
              )}
            </div>

            {/* STEP 2: Copy PowerShell Command */}
            <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-slate-800 text-white flex items-center justify-center font-bold text-xs">
                    2
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-blue-600" />
                      <span>Copy & Paste Command in PowerShell</span>
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Run this command in PowerShell to connect and stream activity continuously
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={copyRunCommand}
                  className="inline-flex items-center gap-1.5 text-xs text-blue-600 hover:text-blue-700 font-semibold bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                >
                  {copiedScriptCommand ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Command</span>
                    </>
                  )}
                </button>
              </div>

              {/* Primary execution command */}
              <div className="bg-slate-900 text-slate-100 p-3.5 rounded-lg font-mono text-xs overflow-x-auto select-all leading-relaxed">
                <code>{runDownloadedScriptCommand}</code>
              </div>

              <div className="text-[11px] text-slate-500 flex items-center gap-1.5 pt-1">
                <span>Tip: Click &quot;Download Script&quot; in Step 1 first, then paste the command above into your PowerShell window.</span>
              </div>
            </div>

            {/* STEP 3: Live Connection & Activity Sync Indicator */}
            <div className={`p-4 rounded-xl border transition-all ${
              deviceState.connected
                ? 'border-emerald-300 bg-emerald-50/50'
                : 'border-slate-200 bg-slate-50'
            } flex items-center justify-between gap-4`}>
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                    deviceState.connected
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {deviceState.connected ? (
                    <Activity className="w-5 h-5 text-emerald-600 animate-pulse" />
                  ) : (
                    <Laptop className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-900 flex items-center gap-2 flex-wrap">
                    <StatusBadge connected={deviceState.connected} />
                    <span>
                      {deviceState.connected
                        ? 'Agent is sending activity'
                        : 'Waiting for the Windows agent to connect'}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600 mt-1">
                    {deviceState.statusText} · Last successful connection: {formatDateTime(deviceState.lastSuccessfulConnectionAt)}
                  </div>
                  {!deviceState.connected && (
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Paste the command in PowerShell and keep that window open. This panel turns to Connected automatically.
                    </div>
                  )}
                </div>
              </div>

              <button
                type="button"
                onClick={handleVerifyConnection}
                disabled={isConnecting}
                className="inline-flex items-center gap-1.5 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs font-medium px-3.5 py-1.5 rounded-lg shadow-2xs transition-colors cursor-pointer disabled:opacity-60 shrink-0"
              >
                {isConnecting ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600" />
                ) : (
                  <Zap className="w-3.5 h-3.5 text-blue-600" />
                )}
                <span>{isConnecting ? 'Verifying...' : 'Verify Connection'}</span>
              </button>
            </div>

            {verifyMessage && (
              <div
                className={`text-[11px] px-3 py-2 rounded-lg border ${
                  deviceState.connected
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-700'
                }`}
              >
                {verifyMessage}
              </div>
            )}

            {/* Action buttons */}
            <div className="pt-2 flex items-center justify-between gap-3">
              <div className="text-[11px] text-slate-500">
                {deviceState.connected ? (
                  <span className="text-emerald-700 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Connected. You can open the dashboard.
                  </span>
                ) : (
                  <span className="text-rose-700">The dashboard unlocks once the device is connected.</span>
                )}
              </div>

              <button
                type="button"
                onClick={onComplete}
                disabled={!deviceState.connected}
                className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-medium px-6 py-2.5 rounded-xl text-xs shadow-xs transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-blue-600"
              >
                <span>Continue to Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="text-xs text-slate-400 text-center flex items-center gap-1.5">
        <Shield className="w-3.5 h-3.5 text-slate-400" />
        <span>Privacy Protected: Only foreground application titles are monitored. Keystrokes & screens are never stored.</span>
      </footer>
    </div>
  );
};
