import React from 'react';
import {
  ArrowRight,
  Clock,
  Shield,
  Sparkles,
} from 'lucide-react';

interface SplashScreenProps {
  onSignIn: () => void;
  onRegisteredReconnect: () => void;
  isRegistered?: boolean;
  userName?: string;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onSignIn,
  onRegisteredReconnect,
  isRegistered = false,
  userName,
}) => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between items-center px-4 py-8 sm:py-12 relative overflow-hidden selection:bg-blue-100 font-sans">
      {/* Background ambient lighting */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-gradient-to-tr from-blue-100 to-emerald-100 rounded-full blur-3xl" />
      </div>

      {/* Top micro brand mark */}
      <header className="relative z-10 w-full max-w-4xl flex justify-between items-center">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs">
            <Clock className="w-4 h-4 stroke-[2.2]" />
          </div>
          <span className="font-semibold text-slate-900 tracking-tight text-base">ChronoTrace</span>
        </div>
        <div className="text-xs text-slate-500 flex items-center gap-1.5 font-medium">
          <Shield className="w-3.5 h-3.5 text-emerald-600" />
          <span>Privacy-First Timeline Reconstruction</span>
        </div>
      </header>

      {/* Main hero area */}
      <main className="relative z-10 w-full max-w-xl my-auto text-center flex flex-col items-center py-6 sm:py-10">
        {/* Brand Icon */}
        <div className="w-16 h-16 rounded-2xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-600/20 mb-6">
          <Clock className="w-8 h-8 stroke-[2]" />
        </div>

        <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-slate-900 mb-3">
          ChronoTrace
        </h1>

        <p className="text-base sm:text-lg text-slate-600 max-w-md mb-8 leading-relaxed">
          Understand your day. Reconstruct your focus. Resume with clarity.
        </p>

        {/* Subtle horizontal activity timeline visualization */}
        <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl p-4 shadow-xs mb-8">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2.5 font-medium">
            <span>Passive Work Timeline</span>
            <span className="text-blue-600 flex items-center gap-1 font-semibold text-[11px]">
              <Sparkles className="w-3 h-3" />
              AI Cognitive Flow
            </span>
          </div>

          {/* Activity visualization bar */}
          <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden flex gap-1 p-0.5">
            <div className="h-full bg-emerald-500 rounded-sm w-[35%]" title="Deep Work" />
            <div className="h-full bg-blue-500 rounded-sm w-[25%]" title="Learning & Docs" />
            <div className="h-full bg-rose-400 rounded-sm w-[15%]" title="Distraction" />
            <div className="h-full bg-emerald-500 rounded-sm w-[20%]" title="Focused Execution" />
            <div className="h-full bg-slate-300 rounded-sm w-[5%]" title="Transition" />
          </div>

          {/* Legend */}
          <div className="flex items-center justify-between mt-3 text-[11px] text-slate-500 px-1">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span>Deep Work</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-500" />
              <span>Learning</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-400" />
              <span>Distraction</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-slate-300" />
              <span>Break</span>
            </div>
          </div>
        </div>

        {/* Primary Call to Action */}
        {isRegistered ? (
          <div className="w-full max-w-sm flex flex-col items-center gap-3">
            <button
              type="button"
              onClick={onRegisteredReconnect}
              className="w-full py-3.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-medium text-sm flex items-center justify-center gap-2 shadow-sm shadow-blue-500/20 transition-all cursor-pointer group"
            >
              <span>Continue to Device Connection</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            <button
              type="button"
              onClick={onSignIn}
              className="text-xs text-slate-500 hover:text-slate-800 transition-colors cursor-pointer py-1"
            >
              Sign in with another account
            </button>
          </div>
        ) : (
          <div className="w-full max-w-sm">
            <button
              type="button"
              onClick={onSignIn}
              className="w-full py-3.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-medium text-sm flex items-center justify-center gap-2 shadow-sm shadow-blue-500/20 transition-all cursor-pointer group"
            >
              <span>Get Started</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full max-w-4xl text-center text-xs text-slate-400 py-2">
        <p>Passive activity reconstruction · No keystroke contents, passwords, or screens are ever recorded</p>
      </footer>
    </div>
  );
};
