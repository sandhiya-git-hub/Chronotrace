import React, { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { GoogleAuthScreen } from './components/GoogleAuthScreen';
import { DeviceSetupScreen } from './components/DeviceSetupScreen';
import { DeviceLockedView } from './components/DeviceLockedView';
import { AppHeader } from './components/AppHeader';
import { DashboardView } from './components/DashboardView';
import { ActivityTimelineView } from './components/ActivityTimelineView';
import { RawActivityView } from './components/RawActivityView';
import { AiAssistantView } from './components/AiAssistantView';
import { DeviceModal } from './components/DeviceModal';
import { PrivacyModal } from './components/PrivacyModal';
import {
  AppScreen,
  ChunkSummary,
  DailySynthesis,
  DeviceState,
  IntentLabel,
  PrimaryNavTab,
  ReentryBriefing,
  TelemetryEvent,
  UserProfile,
} from '@shared/types/chronotrace';

export default function App() {
  // Navigation & Screen Lifecycle
  const [screen, setScreen] = useState<AppScreen>('splash');
  const [activeTab, setActiveTab] = useState<PrimaryNavTab>('dashboard');
  const [selectedDateRange, setSelectedDateRange] = useState<string>('Today');

  // Core Data
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isRegisteredUser, setIsRegisteredUser] = useState<boolean>(true);
  const [device, setDevice] = useState<DeviceState | null>(null);
  const [events, setEvents] = useState<TelemetryEvent[]>([]);
  const [chunks, setChunks] = useState<ChunkSummary[]>([]);
  const [dailySummary, setDailySummary] = useState<DailySynthesis | null>(null);
  const [reentryBriefing, setReentryBriefing] = useState<ReentryBriefing | null>(null);

  // States & Modals
  const [isSynthesizing, setIsSynthesizing] = useState<boolean>(false);
  const [deviceModalOpen, setDeviceModalOpen] = useState<boolean>(false);
  const [privacyModalOpen, setPrivacyModalOpen] = useState<boolean>(false);
  const [initialAssistantPrompt, setInitialAssistantPrompt] = useState<string | undefined>(undefined);

  const safeFetchJson = async (url: string) => {
    try {
      const res = await fetch(url);
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  };

  const fetchDeviceStatus = async () => {
    const data = await safeFetchJson('/api/device/status');
    if (data) setDevice(data);
  };

  // Check initial authentication and fetch core datasets once on mount
  useEffect(() => {
    checkAuthAndInit();
  }, []);

  // Live polling for continuous telemetry stream when on app or device screens
  useEffect(() => {
    if (screen !== 'app' && screen !== 'device') return;

    const interval = setInterval(() => {
      fetchAllActivityData();
      fetchDeviceStatus();
    }, 3000);

    return () => clearInterval(interval);
  }, [screen]);

  // Bridge local Windows agent (http://127.0.0.1:9876) running on user's machine to the website
  useEffect(() => {
    let active = true;
    const bridgeInterval = setInterval(async () => {
      try {
        const localRes = await fetch('http://127.0.0.1:9876/', {
          mode: 'cors',
          cache: 'no-cache',
        });
        if (localRes.ok && active) {
          const localData = await localRes.json();
          if (localData && localData.status === 'ok') {
            await fetch('/api/ingest-event', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                appName: localData.appName,
                windowTitle: localData.windowTitle,
                overrideCategory: localData.category,
                overrideTask: localData.specificTask,
                deltaSeconds: 2,
                userToken: localData.userToken || user?.deviceToken,
                deviceName: localData.deviceName,
                os: localData.os,
              }),
            });
            fetchDeviceStatus();
          }
        }
      } catch {
        // Local agent not active on 9876
      }
    }, 2000);

    return () => {
      active = false;
      clearInterval(bridgeInterval);
    };
  }, [user]);

  const checkAuthAndInit = async () => {
    try {
      // 1. Check existing auth session
      const authRes = await safeFetchJson('/api/auth/session');
      if (authRes?.authenticated && authRes.user) {
        setUser(authRes.user);
        setIsRegisteredUser(authRes.user.isRegistered !== false);

        // Fetch device status
        const devRes = await safeFetchJson('/api/device/status');
        if (devRes) setDevice(devRes);

        // Load core activity datasets
        await fetchAllActivityData();

        // Restore screen to app (or device if first-time setup needed)
        if (devRes?.connected || devRes?.lastSuccessfulConnectionAt) {
          setScreen('app');
        } else {
          setScreen('device');
        }
      } else {
        // Not authenticated: stay on splash
        const devRes = await safeFetchJson('/api/device/status');
        if (devRes) setDevice(devRes);
      }
    } catch {
      // Non-fatal init fallback
    }
  };

  const fetchAllActivityData = async () => {
    try {
      const [eventsRes, sessionsRes, summaryRes, reentryRes] = await Promise.all([
        safeFetchJson('/api/telemetry/raw?limit=100'),
        safeFetchJson('/api/sessions'),
        safeFetchJson('/api/summary/today'),
        safeFetchJson('/api/reentry/TS%20Assignment'),
      ]);

      if (eventsRes?.events && Array.isArray(eventsRes.events)) {
        setEvents(eventsRes.events);
      } else if (Array.isArray(eventsRes)) {
        setEvents(eventsRes);
      }

      if (Array.isArray(sessionsRes)) setChunks(sessionsRes);
      if (summaryRes) setDailySummary(summaryRes);
      if (reentryRes) setReentryBriefing(reentryRes);
    } catch {
      // Gracefully retain current datasets if a momentary network error occurs
    }
  };

  // Auth flow transitions
  const handleAuthSuccess = (authenticatedUser: UserProfile, isFirstTime: boolean = false) => {
    setUser(authenticatedUser);
    setIsRegisteredUser(!isFirstTime);
    // After login, route to device connecting page:
    // - If first-time user: device page with PowerShell command copy
    // - If already registered user: device page with ON/OFF toggle
    setScreen('device');
  };

  const handleDeviceSetupComplete = async () => {
    // The dashboard opens only if the server confirms the device is connected right now.
    try {
      const devRes = await fetch('/api/device/status').then((r) => r.json());
      setDevice(devRes);
      if (!devRes.connected) return;
    } catch {
      return;
    }
    setScreen('app');
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {}
    setUser(null);
    setIsRegisteredUser(false);
    setScreen('splash');
  };

  const handleRefreshSummary = async () => {
    setIsSynthesizing(true);
    try {
      const res = await fetch('/api/gemini/synthesize-day', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessions: chunks }),
      });
      if (res.ok) {
        const data = await res.json();
        setDailySummary(data);
      }
    } catch (e) {
      console.error('Error refreshing summary:', e);
    } finally {
      setIsSynthesizing(false);
    }
  };

  const handleCorrectIntent = async (chunkId: string, newIntent: IntentLabel) => {
    try {
      const res = await fetch(`/api/sessions/${chunkId}/correct`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ intent: newIntent }),
      });
      if (res.ok) {
        setChunks((prev) =>
          prev.map((c) =>
            c.chunk_id === chunkId
              ? { ...c, intent: newIntent, user_corrected: true }
              : c
          )
        );
      }
    } catch (e) {
      console.error('Error updating intent:', e);
    }
  };

  const handleNavigateToAssistantWithPrompt = (prompt?: string) => {
    setInitialAssistantPrompt(prompt);
    setActiveTab('assistant');
  };

  // -------------------------------------------------------------
  // USER JOURNEY RENDER ROUTING
  // -------------------------------------------------------------

  // Stage 1: Splash Screen
  if (screen === 'splash') {
    return (
      <SplashScreen
        isRegistered={Boolean(user && isRegisteredUser)}
        userName={user?.name || user?.givenName}
        onSignIn={() => {
          // Flow 1: Splash -> asks user to login by username/password & Google account -> then device -> dashboard
          setIsRegisteredUser(false);
          setScreen('auth');
        }}
        onRegisteredReconnect={() => {
          // If already authenticated: go to device page or dashboard
          if (user) {
            setIsRegisteredUser(true);
            setScreen('device');
          } else {
            // Require login
            setIsRegisteredUser(true);
            setScreen('auth');
          }
        }}
      />
    );
  }

  // Stage 2: Authentication (Username & Password + Google OAuth - correct details only)
  if (screen === 'auth') {
    return (
      <GoogleAuthScreen
        onSuccess={handleAuthSuccess}
        onBackToSplash={() => setScreen('splash')}
      />
    );
  }

  // Stage 3: Windows Device Connecting Page
  // - First-time: copying PowerShell command to connect device with website
  // - Already registered: on and off toggle for connecting again with website for productivity activity reconstruction
  if (screen === 'device') {
    return (
      <DeviceSetupScreen
        isRegisteredUser={isRegisteredUser}
        user={user}
        onBack={() => setScreen(isRegisteredUser ? 'splash' : 'auth')}
        onComplete={handleDeviceSetupComplete}
      />
    );
  }

  // Stage 4 gate: if device has never connected and has no recorded data, show the connection setup screen
  const hasDeviceActivity = Boolean(
    device?.connected || device?.lastSuccessfulConnectionAt || chunks.length > 0 || events.length > 0
  );
  if (!device?.connected && !hasDeviceActivity) {
    return (
      <DeviceLockedView
        device={device}
        chunks={chunks}
        onReconnect={() => setScreen('device')}
        onLogout={handleLogout}
      />
    );
  }

  // Stage 5: Main Application (Dashboard, Activity Timeline, Raw Activity, AI Assistant)
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-blue-100">
      {/* Persistent Navigation Header */}
      <AppHeader
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        user={user}
        device={device}
        onOpenDeviceModal={() => setDeviceModalOpen(true)}
        onOpenPrivacyModal={() => setPrivacyModalOpen(true)}
        onLogout={handleLogout}
        onNavigateToDeviceScreen={() => setScreen('device')}
      />

      {/* Main Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {/* Section 1: Dashboard */}
        {activeTab === 'dashboard' && (
          <DashboardView
            user={user}
            summary={dailySummary}
            chunks={chunks}
            events={events}
            reentry={reentryBriefing}
            onRefreshSummary={handleRefreshSummary}
            isSynthesizing={isSynthesizing}
            onNavigateToTimeline={() => setActiveTab('timeline')}
            onNavigateToAssistant={handleNavigateToAssistantWithPrompt}
          />
        )}

        {/* Section 2: Activity Timeline */}
        {activeTab === 'timeline' && (
          <ActivityTimelineView
            chunks={chunks}
            onCorrectIntent={handleCorrectIntent}
          />
        )}

        {/* Section 3: Raw Activity */}
        {activeTab === 'raw' && <RawActivityView events={events} />}

        {/* Section 4: AI Assistant */}
        {activeTab === 'assistant' && (
          <AiAssistantView
            initialPrompt={initialAssistantPrompt}
            onNavigateToTimeline={() => setActiveTab('timeline')}
          />
        )}
      </main>

      {/* Device Connection Modal */}
      {deviceModalOpen && (
        <DeviceModal
          device={device}
          onClose={() => setDeviceModalOpen(false)}
          onRefresh={async () => {
            const devRes = await fetch('/api/device/status').then((r) => r.json());
            setDevice(devRes);
          }}
        />
      )}

      {/* Privacy Guarantee Modal */}
      {privacyModalOpen && (
        <PrivacyModal onClose={() => setPrivacyModalOpen(false)} />
      )}
    </div>
  );
}
