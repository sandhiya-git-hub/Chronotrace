import React, { useState, useEffect } from 'react';
import {
  User,
  Mail,
  Laptop,
  Target,
  Shield,
  Save,
  CheckCircle2,
  Settings,
  Layers,
  Clock,
  Briefcase,
  Sliders,
} from 'lucide-react';
import userAvatar from '../assets/images/timetrace_avatar_user_1791535524978.jpg';

export const ProfilePage: React.FC = () => {
  const [profile, setProfile] = useState<any>({
    name: 'Sandhiya Sankar',
    email: 'sandhiyasankarpersonal@gmail.com',
    role: 'Software Engineer & Researcher',
    timezone: 'Asia/Kolkata (IST)',
    connectedDevice: 'ThinkPad X1 Carbon Gen 11 - Windows 11 Pro',
    deviceOs: 'Windows 11 Pro 64-bit Build 22631',
    agentVersion: 'v1.4.2-win32',
    dailyDeepWorkGoalHours: 4.5,
    maxContextSwitchesGoal: 25,
    focusProjects: ['Time Trace Architecture', 'Full-Stack Dev Learning', 'Cognitive Modeling'],
    trackingPreferences: {
      captureForegroundWindow: true,
      countKeystrokesAnonymously: true,
      trackRapidSwitches: true,
      excludePrivateBrowserTabs: true,
    },
  });

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  useEffect(() => {
    fetch('/api/user/profile')
      .then((r) => r.json())
      .then((data) => {
        if (data && data.name) setProfile(data);
      })
      .catch((err) => console.error('Error fetching profile:', err));
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const res = await fetch('/api/user/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profile),
      });
      if (res.ok) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (err) {
      console.error('Error saving profile:', err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300 max-w-4xl mx-auto">
      {/* Header */}
      <div className="border-b border-stone-200 pb-5">
        <div className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-semibold mb-1">
          Identity & Tracking Configuration
        </div>
        <h1 className="text-2xl sm:text-3xl font-serif font-medium text-stone-900 tracking-tight">
          User Profile & Productivity Goals
        </h1>
        <p className="text-sm text-stone-600 mt-0.5 font-sans">
          Manage your personal identity, connected hardware devices, and daily deep work focus targets.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900 text-xs flex items-center justify-between animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span className="font-medium">Profile and productivity goals saved successfully.</span>
          </div>
          <span className="font-mono text-[11px] text-emerald-700">Persisted</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Profile Card */}
        <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-6 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-emerald-800/20 shadow-md shrink-0">
              <img
                src={userAvatar}
                alt="User Profile Portrait"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="space-y-1">
              <h2 className="text-xl font-serif font-medium text-stone-900">{profile.name}</h2>
              <div className="flex flex-wrap items-center gap-3 text-xs text-stone-600 font-sans">
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-stone-400" />
                  {profile.email}
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <Briefcase className="w-3.5 h-3.5 text-stone-400" />
                  {profile.role}
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-stone-100">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Full Name</label>
              <input
                type="text"
                value={profile.name}
                onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-emerald-800 text-stone-900"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Email Address</label>
              <input
                type="email"
                value={profile.email}
                onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-emerald-800 text-stone-900"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Professional Role</label>
              <input
                type="text"
                value={profile.role}
                onChange={(e) => setProfile({ ...profile, role: e.target.value })}
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-emerald-800 text-stone-900"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Timezone</label>
              <input
                type="text"
                value={profile.timezone}
                onChange={(e) => setProfile({ ...profile, timezone: e.target.value })}
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-emerald-800 text-stone-900"
              />
            </div>
          </div>
        </div>

        {/* Connected Hardware Device Card */}
        <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Laptop className="w-4 h-4 text-emerald-800" />
            <h3 className="text-sm font-semibold text-stone-900">Connected Hardware Devices</h3>
          </div>

          <div className="p-4 bg-stone-50 rounded-lg border border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-600" />
                <span className="text-xs font-semibold text-stone-900">{profile.connectedDevice}</span>
              </div>
              <div className="text-[11px] text-stone-500 font-mono">
                OS: {profile.deviceOs} · Collector Agent: {profile.agentVersion}
              </div>
            </div>
            <span className="text-[11px] font-mono font-medium px-2.5 py-1 rounded bg-emerald-100 text-emerald-800 border border-emerald-200 self-start sm:self-auto">
              ONLINE & ACTIVE
            </span>
          </div>
        </div>

        {/* Productivity Goals */}
        <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4 text-emerald-800" />
            <h3 className="text-sm font-semibold text-stone-900">Personal Productivity Goals</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Daily Deep Work Target (Hours)
              </label>
              <input
                type="number"
                step="0.5"
                min="1"
                max="12"
                value={profile.dailyDeepWorkGoalHours}
                onChange={(e) =>
                  setProfile({ ...profile, dailyDeepWorkGoalHours: parseFloat(e.target.value) || 4 })
                }
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-emerald-800 text-stone-900 font-mono"
              />
              <span className="text-[10px] text-stone-400 mt-1 block">
                Recommended baseline for sustained software engineering is 4.0 - 5.0h.
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Max Allowed Context Switches (Per Day)
              </label>
              <input
                type="number"
                min="5"
                max="100"
                value={profile.maxContextSwitchesGoal}
                onChange={(e) =>
                  setProfile({ ...profile, maxContextSwitchesGoal: parseInt(e.target.value) || 25 })
                }
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-emerald-800 text-stone-900 font-mono"
              />
              <span className="text-[10px] text-stone-400 mt-1 block">
                Target boundary to avoid cognitive restlessness and fragmentation.
              </span>
            </div>
          </div>
        </div>

        {/* Tracking & Privacy Preferences */}
        <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-800" />
            <h3 className="text-sm font-semibold text-stone-900">Passive Tracking Preferences</h3>
          </div>

          <div className="space-y-3">
            {[
              {
                key: 'captureForegroundWindow',
                title: 'Foreground Window Title Sampling',
                desc: 'Collect active application names and window titles to identify cognitive tasks.',
              },
              {
                key: 'countKeystrokesAnonymously',
                title: 'Anonymous Keystroke Counter',
                desc: 'Record keypress frequency rate without logging typed characters or credentials.',
              },
              {
                key: 'trackRapidSwitches',
                title: 'Rapid Micro-Switching Detection',
                desc: 'Cluster transitions under 10s into restless or tab-hunting behavioral patterns.',
              },
              {
                key: 'excludePrivateBrowserTabs',
                title: 'Exclude InPrivate / Incognito Windows',
                desc: 'Automatically omit window titles containing private browsing keywords.',
              },
            ].map((pref) => (
              <label
                key={pref.key}
                className="flex items-start gap-3 p-3 bg-stone-50 rounded-lg border border-stone-200 cursor-pointer hover:bg-stone-100/60 transition-colors"
              >
                <input
                  type="checkbox"
                  checked={profile.trackingPreferences?.[pref.key] ?? true}
                  onChange={(e) =>
                    setProfile({
                      ...profile,
                      trackingPreferences: {
                        ...profile.trackingPreferences,
                        [pref.key]: e.target.checked,
                      },
                    })
                  }
                  className="mt-0.5 accent-emerald-800"
                />
                <div>
                  <div className="text-xs font-semibold text-stone-800">{pref.title}</div>
                  <div className="text-[11px] text-stone-500 leading-relaxed">{pref.desc}</div>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-2.5 rounded-lg text-xs font-semibold bg-emerald-800 hover:bg-emerald-900 text-white transition-colors flex items-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving Profile...' : 'Save Profile Changes'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
