import React, { useState, useEffect } from 'react';
import {
  Settings,
  Laptop,
  Shield,
  Sparkles,
  Palette,
  Download,
  Trash2,
  Pause,
  Play,
  Save,
  CheckCircle2,
  AlertTriangle,
  Info,
  Clock,
  Database,
  Layers,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<any>({
    theme: 'light',
    timeFormat: '24h',
    defaultDateRange: 'today',
    collectionIntervalMs: 500,
    idleGapThresholdS: 60,
    autoStartOnBoot: true,
    enableAiSynthesis: true,
    enableReentryBriefings: true,
    dataRetentionDays: 30,
    anonymizeWindowTitles: false,
    soundEffects: false,
  });

  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [showClearModal, setShowClearModal] = useState<boolean>(false);
  const [clearConfirmationInput, setClearConfirmationInput] = useState<string>('');
  const [clearStatus, setClearStatus] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState<boolean>(false);

  useEffect(() => {
    fetch('/api/user/settings')
      .then((r) => r.json())
      .then((data) => {
        if (data) setSettings(data);
      })
      .catch((err) => console.error('Error fetching settings:', err));
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const res = await fetch('/api/user/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      }
    } catch (err) {
      console.error('Error saving settings:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportData = () => {
    setIsExporting(true);
    window.location.href = '/api/data/export';
    setTimeout(() => setIsExporting(false), 1500);
  };

  const handleClearData = async () => {
    if (clearConfirmationInput !== 'CLEAR_ACTIVITY_DATA') return;
    try {
      const res = await fetch('/api/data/clear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ confirmation: 'CLEAR_ACTIVITY_DATA' }),
      });
      if (res.ok) {
        setClearStatus('Records reset successfully.');
        setTimeout(() => {
          setShowClearModal(false);
          setClearStatus(null);
          setClearConfirmationInput('');
        }, 1500);
      }
    } catch (err) {
      console.error('Error clearing data:', err);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300 max-w-4xl mx-auto">
      {/* Header */}
      <div className="border-b border-stone-200 pb-5">
        <div className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-semibold mb-1">
          System Configuration
        </div>
        <h1 className="text-2xl sm:text-3xl font-serif font-medium text-stone-900 tracking-tight">
          Application & Telemetry Settings
        </h1>
        <p className="text-sm text-stone-600 mt-0.5 font-sans">
          Configure collection cadence, storage retention, privacy boundaries, and AI model parameters.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900 text-xs flex items-center justify-between animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span className="font-medium">Settings updated and saved to local configuration.</span>
          </div>
          <span className="font-mono text-[11px] text-emerald-700">Saved</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-8">
        {/* SECTION 1: DEVICE AND TELEMETRY */}
        <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-6 space-y-5">
          <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
            <Laptop className="w-4 h-4 text-emerald-800" />
            <h2 className="text-sm font-semibold text-stone-900">Device and Telemetry</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Sampling Interval (Milliseconds)
              </label>
              <select
                value={settings.collectionIntervalMs}
                onChange={(e) =>
                  setSettings({ ...settings, collectionIntervalMs: parseInt(e.target.value) })
                }
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 font-mono focus:outline-none"
              >
                <option value="250">250 ms (Ultra High Resolution)</option>
                <option value="500">500 ms (Standard Default)</option>
                <option value="1000">1000 ms (Low CPU Mode)</option>
              </select>
              <span className="text-[10px] text-stone-400 mt-1 block">
                How frequently the Windows pywin32 hook inspects foreground transitions.
              </span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Inactivity / Idle Boundary Trigger
              </label>
              <select
                value={settings.idleGapThresholdS}
                onChange={(e) =>
                  setSettings({ ...settings, idleGapThresholdS: parseInt(e.target.value) })
                }
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 font-mono focus:outline-none"
              >
                <option value="30">30 seconds</option>
                <option value="60">60 seconds (Standard)</option>
                <option value="120">120 seconds (Deep Flow)</option>
                <option value="300">300 seconds (Relaxed)</option>
              </select>
              <span className="text-[10px] text-stone-400 mt-1 block">
                Duration of zero keyboard and window events before auto-finalizing a chunk.
              </span>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <label className="flex items-start gap-3 p-3 bg-stone-50 rounded-lg border border-stone-200 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.autoStartOnBoot}
                onChange={(e) => setSettings({ ...settings, autoStartOnBoot: e.target.checked })}
                className="mt-0.5 accent-emerald-800"
              />
              <div>
                <div className="text-xs font-semibold text-stone-800">Launch On Windows Startup</div>
                <div className="text-[11px] text-stone-500">
                  Automatically start background Python agent collector on laptop boot.
                </div>
              </div>
            </label>
          </div>
        </div>

        {/* SECTION 2: PRIVACY AND DATA MANAGEMENT */}
        <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-6 space-y-5">
          <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
            <Shield className="w-4 h-4 text-emerald-800" />
            <h2 className="text-sm font-semibold text-stone-900">Privacy & Data Management</h2>
          </div>

          <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-lg text-xs space-y-2">
            <div className="font-semibold text-emerald-950">What ChronoTrace Collects:</div>
            <ul className="list-disc list-inside space-y-1 text-emerald-900 leading-relaxed text-[11px]">
              <li>Active foreground window title and process name (e.g. Chrome, VS Code).</li>
              <li>Dwell duration spent continuously in that window before next transition.</li>
              <li>Anonymized keypress frequency counters (number of taps per minute, zero keylogging).</li>
            </ul>
            <div className="text-[11px] text-emerald-800 font-semibold pt-1">
              Zero screen recordings. Zero password capture. Zero cloud upload without your consent.
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Data Retention Period
              </label>
              <select
                value={settings.dataRetentionDays}
                onChange={(e) =>
                  setSettings({ ...settings, dataRetentionDays: parseInt(e.target.value) })
                }
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 font-mono focus:outline-none"
              >
                <option value="7">7 Days</option>
                <option value="30">30 Days (Recommended)</option>
                <option value="90">90 Days</option>
                <option value="365">365 Days (1 Year)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Window Title Sanitization
              </label>
              <select
                value={settings.anonymizeWindowTitles ? 'true' : 'false'}
                onChange={(e) =>
                  setSettings({ ...settings, anonymizeWindowTitles: e.target.value === 'true' })
                }
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 font-mono focus:outline-none"
              >
                <option value="false">Store Full Window Titles</option>
                <option value="true">Mask Titles to App Name Only</option>
              </select>
            </div>
          </div>

          {/* Export and Clear Actions */}
          <div className="pt-4 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleExportData}
              disabled={isExporting}
              className="px-4 py-2 text-xs font-medium bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg transition-colors border border-stone-300 flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isExporting ? 'Exporting JSON...' : 'Export Recorded Activity (JSON)'}</span>
            </button>

            <button
              type="button"
              onClick={() => setShowClearModal(true)}
              className="px-4 py-2 text-xs font-medium bg-rose-50 hover:bg-rose-100 text-rose-800 rounded-lg transition-colors border border-rose-200 flex items-center gap-2 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Activity Database</span>
            </button>
          </div>
        </div>

        {/* SECTION 3: AI CONFIGURATION */}
        <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-6 space-y-5">
          <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
            <Sparkles className="w-4 h-4 text-emerald-800" />
            <h2 className="text-sm font-semibold text-stone-900">AI Intelligence Configuration</h2>
          </div>

          <div className="p-3.5 bg-stone-50 rounded-lg border border-stone-200 flex items-center justify-between text-xs">
            <div className="space-y-0.5">
              <div className="font-semibold text-stone-900">LLM Engine: Gemini 3.8 Flash</div>
              <div className="text-[11px] text-stone-500 font-mono">
                SDK: @google/genai · User-Agent: aistudio-build · Server-Side Proxy
              </div>
            </div>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold">
              CONNECTED
            </span>
          </div>

          <div className="space-y-3">
            <label className="flex items-start gap-3 p-3 bg-stone-50 rounded-lg border border-stone-200 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.enableAiSynthesis}
                onChange={(e) =>
                  setSettings({ ...settings, enableAiSynthesis: e.target.checked })
                }
                className="mt-0.5 accent-emerald-800"
              />
              <div>
                <div className="text-xs font-semibold text-stone-800">
                  Enable End-of-Day Cognitive Synthesis
                </div>
                <div className="text-[11px] text-stone-500">
                  Analyze daily chunks at 21:00 to generate narrative summaries and distraction alerts.
                </div>
              </div>
            </label>

            <label className="flex items-start gap-3 p-3 bg-stone-50 rounded-lg border border-stone-200 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.enableReentryBriefings}
                onChange={(e) =>
                  setSettings({ ...settings, enableReentryBriefings: e.target.checked })
                }
                className="mt-0.5 accent-emerald-800"
              />
              <div>
                <div className="text-xs font-semibold text-stone-800">
                  Enable Laptop Wake Re-entry Briefings
                </div>
                <div className="text-[11px] text-stone-500">
                  Restore cognitive context ("Last time on this project...") upon waking laptop.
                </div>
              </div>
            </label>
          </div>
        </div>

        {/* SECTION 4: APPEARANCE AND PREFERENCES */}
        <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-6 space-y-5">
          <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
            <Palette className="w-4 h-4 text-emerald-800" />
            <h2 className="text-sm font-semibold text-stone-900">Appearance & Preferences</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Color Theme</label>
              <select
                value={settings.theme}
                onChange={(e) => setSettings({ ...settings, theme: e.target.value })}
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 focus:outline-none"
              >
                <option value="light">Warm Editorial Light (Default)</option>
                <option value="system">Follow System Preferences</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Time Format</label>
              <select
                value={settings.timeFormat}
                onChange={(e) => setSettings({ ...settings, timeFormat: e.target.value })}
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 focus:outline-none font-mono"
              >
                <option value="24h">24-Hour (18:55)</option>
                <option value="12h">12-Hour AM/PM (6:55 PM)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Default Dashboard Range
              </label>
              <select
                value={settings.defaultDateRange}
                onChange={(e) => setSettings({ ...settings, defaultDateRange: e.target.value })}
                className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2.5 focus:outline-none"
              >
                <option value="today">Today</option>
                <option value="7d">Last 7 Days</option>
                <option value="30d">Last 30 Days</option>
              </select>
            </div>
          </div>
        </div>

        {/* Submit */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={isSaving}
            className="px-6 py-2.5 rounded-lg text-xs font-semibold bg-emerald-800 hover:bg-emerald-900 text-white transition-colors flex items-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Saving Settings...' : 'Save Settings'}</span>
          </button>
        </div>
      </form>

      {/* Confirmation Modal for Clearing Database */}
      {showClearModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl border border-stone-200 shadow-2xl max-w-md w-full p-6 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-2 text-rose-700">
              <AlertTriangle className="w-5 h-5" />
              <h3 className="text-base font-semibold text-stone-900">Clear Stored Activity Data</h3>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              This action resets your local recorded session chunks and raw telemetry logs in <span className="font-mono text-stone-800">chronotrace.db</span>. This cannot be undone.
            </p>

            <div className="space-y-1">
              <label className="text-xs text-stone-500 font-medium">
                Type <strong className="text-stone-900 font-mono">CLEAR_ACTIVITY_DATA</strong> to confirm:
              </label>
              <input
                type="text"
                value={clearConfirmationInput}
                onChange={(e) => setClearConfirmationInput(e.target.value)}
                placeholder="CLEAR_ACTIVITY_DATA"
                className="w-full text-xs font-mono bg-stone-50 border border-stone-300 rounded-lg p-2.5 focus:outline-none focus:ring-1 focus:ring-rose-600 text-stone-900"
              />
            </div>

            {clearStatus && (
              <div className="text-xs text-emerald-700 font-medium">{clearStatus}</div>
            )}

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowClearModal(false);
                  setClearConfirmationInput('');
                }}
                className="px-4 py-2 text-xs font-medium bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={clearConfirmationInput !== 'CLEAR_ACTIVITY_DATA'}
                onClick={handleClearData}
                className="px-4 py-2 text-xs font-semibold bg-rose-700 hover:bg-rose-800 text-white rounded-lg cursor-pointer disabled:opacity-40 transition-colors"
              >
                Permanently Clear
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
