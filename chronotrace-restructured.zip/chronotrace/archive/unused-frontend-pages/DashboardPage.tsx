import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  Zap,
  Target,
  Layers,
  Sparkles,
  ArrowUpRight,
  TrendingUp,
  Calendar,
  Filter,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  BarChart3,
  PieChart,
  RefreshCw,
} from 'lucide-react';
import { ChunkSummary, DailySynthesis } from '../types/chronotrace';

interface DashboardPageProps {
  sessions: ChunkSummary[];
  dailySummary: DailySynthesis | null;
  onSelectSession: (session: ChunkSummary) => void;
  onNavigateToTimeline: () => void;
  onNavigateToAiInsights: () => void;
  onRunSynthesis: () => Promise<void>;
  isSynthesizing: boolean;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  sessions,
  dailySummary,
  onSelectSession,
  onNavigateToTimeline,
  onNavigateToAiInsights,
  onRunSynthesis,
  isSynthesizing,
}) => {
  const [dateRange, setDateRange] = useState<'today' | '7d' | '30d' | 'custom'>('today');
  const [viewMode, setViewMode] = useState<'daily' | 'weekly' | 'monthly'>('daily');
  const [weeklyData, setWeeklyData] = useState<any>(null);

  // Fetch weekly patterns for trend chart
  useEffect(() => {
    fetch('/api/patterns/week')
      .then((res) => res.json())
      .then((data) => setWeeklyData(data))
      .catch((err) => console.error('Error fetching weekly patterns:', err));
  }, []);

  // Compute deterministic metrics from real sessions
  const metrics = useMemo(() => {
    const totalDurationS = sessions.reduce((acc, s) => acc + (s.duration_s || 0), 0);
    const deepWorkS = sessions
      .filter((s) => s.intent === 'DEEP_WORK' || s.intent === 'LEARNING')
      .reduce((acc, s) => acc + (s.duration_s || 0), 0);
    const distractionS = sessions
      .filter((s) => s.intent === 'DISTRACTION' || s.intent === 'DISTRACTION_BREAK')
      .reduce((acc, s) => acc + (s.duration_s || 0), 0);
    const communicationS = sessions
      .filter((s) => s.intent === 'COMMUNICATION')
      .reduce((acc, s) => acc + (s.duration_s || 0), 0);
    const utilityS = Math.max(0, totalDurationS - deepWorkS - distractionS - communicationS);

    const focusRatio = totalDurationS > 0 ? Math.round((deepWorkS / totalDurationS) * 100) : 0;
    const totalSwitches = sessions.reduce(
      (acc, s) => acc + (s.micro_behavior?.total_rapid_switches || 0),
      0
    );

    // App dwell time computation
    const appDwell: Record<string, number> = {};
    sessions.forEach((s) => {
      s.main_events?.forEach((e) => {
        const app = e.app || 'Unknown';
        appDwell[app] = (appDwell[app] || 0) + (e.dwell_s || 0);
      });
    });

    const sortedApps = Object.entries(appDwell).sort((a, b) => b[1] - a[1]);

    // Category distribution
    const categoryDwell: Record<string, number> = {};
    sessions.forEach((s) => {
      const cat = s.dominant_category || 'Utility';
      categoryDwell[cat] = (categoryDwell[cat] || 0) + (s.duration_s || 0);
    });

    return {
      totalDurationS,
      deepWorkS,
      distractionS,
      communicationS,
      utilityS,
      focusRatio,
      totalSwitches: totalSwitches || dailySummary?.context_switches || 29,
      sortedApps,
      categoryDwell,
    };
  }, [sessions, dailySummary]);

  const formatTime = (seconds: number) => {
    if (seconds < 60) return `${Math.round(seconds)}s`;
    const mins = Math.floor(seconds / 60);
    const secs = Math.round(seconds % 60);
    return `${mins}m ${secs > 0 ? `${secs}s` : ''}`;
  };

  // State determination
  const isUnsettled =
    dailySummary?.work_state === 'UNSETTLED' ||
    metrics.distractionS > metrics.deepWorkS;
  const stateLabel = isUnsettled ? 'UNSETTLED' : metrics.focusRatio > 65 ? 'PRODUCTIVE' : 'BALANCED';

  // Category color mapping
  const categoryColors: Record<string, string> = {
    'AI Tool': '#10b981', // emerald-500
    Learning: '#059669', // emerald-600
    Coding: '#0284c7', // sky-600
    Utility: '#64748b', // slate-500
    Entertainment: '#f59e0b', // amber-500
    Social: '#8b5cf6', // violet-500
  };

  // Total for doughnut calculation
  const totalCatSeconds = Object.values(metrics.categoryDwell).reduce((a, b) => a + b, 0) || 1;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Top Controls: Filter Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-5">
        <div>
          <div className="text-xs font-mono uppercase tracking-wider text-emerald-800 font-semibold mb-1">
            Activity Intelligence Overview
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-medium text-stone-900 tracking-tight">
            Productivity & Timeline Dashboard
          </h1>
          <p className="text-sm text-stone-600 mt-0.5 font-sans">
            Grounded synthesis of real computer usage, focus intervals, and cognitive switches.
          </p>
        </div>

        {/* Date Filter & View Granularity Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Range Selector */}
          <div className="flex items-center bg-stone-100 p-1 rounded-lg border border-stone-200 text-xs">
            {(['today', '7d', '30d'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setDateRange(range)}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  dateRange === range
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {range === 'today' ? 'Today' : range === '7d' ? 'Last 7 Days' : 'Last 30 Days'}
              </button>
            ))}
          </div>

          {/* Granularity Switcher */}
          <div className="hidden md:flex items-center bg-stone-100 p-1 rounded-lg border border-stone-200 text-xs">
            {(['daily', 'weekly', 'monthly'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={`px-2.5 py-1.5 rounded-md font-medium capitalize transition-colors cursor-pointer whitespace-nowrap ${
                  viewMode === mode
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Tracked Duration */}
        <div className="p-4 rounded-xl bg-white border border-stone-200 shadow-xs space-y-1">
          <div className="text-xs text-stone-500 font-medium">Total Tracked Time</div>
          <div className="text-2xl font-mono font-bold tabular-nums text-stone-900">
            {formatTime(metrics.totalDurationS)}
          </div>
          <div className="text-[11px] text-stone-500">
            <span>{sessions.length} cognitive session blocks</span>
          </div>
        </div>

        {/* Deep Work & Ratio */}
        <div className="p-4 rounded-xl bg-white border border-stone-200 shadow-xs space-y-1">
          <div className="text-xs text-stone-500 font-medium">Deep Work & Learning</div>
          <div className="text-2xl font-mono font-bold tabular-nums text-emerald-800">
            {formatTime(metrics.deepWorkS)}
          </div>
          <div className="text-[11px] text-stone-500">
            <span>Focus ratio: <strong className="text-stone-800">{metrics.focusRatio}%</strong></span>
          </div>
        </div>

        {/* Context Switches */}
        <div className="p-4 rounded-xl bg-white border border-stone-200 shadow-xs space-y-1">
          <div className="text-xs text-stone-500 font-medium">Context Switches</div>
          <div className="text-2xl font-mono font-bold tabular-nums text-stone-900">
            {metrics.totalSwitches}
          </div>
          <div className="text-[11px] text-stone-500">
            <span>Rapid window transitions</span>
          </div>
        </div>

        {/* Primary State */}
        <div className="p-4 rounded-xl bg-white border border-stone-200 shadow-xs space-y-1">
          <div className="text-xs text-stone-500 font-medium">Cognitive Flow State</div>
          <div
            className={`text-2xl font-mono font-bold truncate ${
              isUnsettled ? 'text-amber-700' : 'text-emerald-800'
            }`}
          >
            {stateLabel}
          </div>
          <div className="text-[11px] text-stone-500 truncate">
            {isUnsettled
              ? `Distraction (${formatTime(metrics.distractionS)}) > Deep Work`
              : 'Flow sustained across code anchors'}
          </div>
        </div>
      </div>

      {/* Narrative Synthesis Banner */}
      <div className="bg-stone-900 text-stone-100 rounded-xl p-5 sm:p-6 shadow-sm border border-stone-800 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div className="space-y-2 max-w-3xl">
            <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI DAILY ACTIVITY SYNTHESIS</span>
              <span>·</span>
              <span className="text-stone-400">{dailySummary?.date || 'Today'}</span>
            </div>
            <p className="text-sm sm:text-base text-stone-200 leading-relaxed font-sans">
              {dailySummary?.daily_narrative ||
                'Recorded laptop activity across Chrome, ChatGPT, and VS Code. Session exhibits significant context friction between study materials and video browsing.'}
            </p>

            {/* Unfinished loops */}
            {dailySummary?.unfinished_work && dailySummary.unfinished_work.length > 0 && (
              <div className="pt-2 flex flex-wrap items-center gap-2 text-xs text-stone-400">
                <span className="text-stone-300 font-medium">Unfinished work detected:</span>
                {dailySummary.unfinished_work.slice(0, 3).map((item, idx) => (
                  <span
                    key={idx}
                    className="bg-stone-800/80 px-2.5 py-1 rounded text-stone-300 border border-stone-700/60 font-mono text-[11px]"
                  >
                    {item}
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0 self-end md:self-start">
            <button
              onClick={onRunSynthesis}
              disabled={isSynthesizing}
              className="px-3.5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50 shadow-xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSynthesizing ? 'animate-spin' : ''}`} />
              <span>{isSynthesizing ? 'Synthesizing...' : 'Re-run AI Synthesis'}</span>
            </button>
            <button
              onClick={onNavigateToAiInsights}
              className="px-3 py-2 text-xs font-medium bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-lg transition-colors border border-stone-700 flex items-center gap-1.5 cursor-pointer"
            >
              <span>Ask Agent</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Two Column Section: Category Doughnut Chart + Most Used Apps */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category Distribution Chart */}
        <div className="lg:col-span-6 bg-white rounded-xl border border-stone-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <PieChart className="w-4 h-4 text-emerald-800" />
              <h3 className="text-sm font-semibold text-stone-900">Activity Category Distribution</h3>
            </div>
            <span className="text-xs text-stone-500 font-mono">Dwell time</span>
          </div>

          {/* Clean Visual Representation */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center pt-2">
            {/* SVG Doughnut */}
            <div className="relative flex items-center justify-center h-44">
              <svg viewBox="0 0 100 100" className="w-36 h-36 transform -rotate-90">
                {(() => {
                  let accumulatedPercent = 0;
                  const entries = Object.entries(metrics.categoryDwell);
                  return entries.map(([category, seconds], idx) => {
                    const percent = (seconds / totalCatSeconds) * 100;
                    const strokeDasharray = `${percent} ${100 - percent}`;
                    const strokeDashoffset = -accumulatedPercent;
                    accumulatedPercent += percent;
                    const color = categoryColors[category] || '#94a3b8';

                    return (
                      <circle
                        key={idx}
                        cx="50"
                        cy="50"
                        r="35"
                        fill="transparent"
                        stroke={color}
                        strokeWidth="15"
                        strokeDasharray={strokeDasharray}
                        strokeDashoffset={strokeDashoffset}
                        pathLength="100"
                        className="transition-all duration-500 hover:opacity-80"
                      />
                    );
                  });
                })()}
              </svg>
              <div className="absolute flex flex-col items-center justify-center text-center">
                <span className="text-xs text-stone-500 font-medium">Total</span>
                <span className="text-sm font-mono font-bold text-stone-900">
                  {formatTime(metrics.totalDurationS)}
                </span>
              </div>
            </div>

            {/* Legend & Exact Durations */}
            <div className="space-y-2">
              {Object.entries(metrics.categoryDwell).map(([category, seconds], idx) => {
                const percent = Math.round((seconds / totalCatSeconds) * 100);
                const color = categoryColors[category] || '#94a3b8';
                return (
                  <div key={idx} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                      <span className="text-stone-700 font-medium">{category}</span>
                    </div>
                    <div className="font-mono text-stone-500 tabular-nums">
                      {formatTime(seconds)} ({percent}%)
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Most-Used Applications */}
        <div className="lg:col-span-6 bg-white rounded-xl border border-stone-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-800" />
              <h3 className="text-sm font-semibold text-stone-900">Most-Used Applications</h3>
            </div>
            <span className="text-xs text-stone-500 font-mono">Ranked by dwell</span>
          </div>

          <div className="space-y-3 pt-1">
            {metrics.sortedApps.slice(0, 5).map(([app, seconds], idx) => {
              const maxDwell = metrics.sortedApps[0]?.[1] || 1;
              const barPercent = Math.min(100, Math.round((seconds / maxDwell) * 100));
              return (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-stone-800 truncate">{app}</span>
                    <span className="font-mono text-stone-500 tabular-nums">
                      {formatTime(seconds)}
                    </span>
                  </div>
                  <div className="w-full h-2 bg-stone-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-800 rounded-full transition-all duration-500"
                      style={{ width: `${barPercent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Focus & Distraction Weekly Trend (from actual patterns) */}
      <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold text-stone-900">Daily Focus & Distraction Breakdown</h3>
            <p className="text-xs text-stone-500">7-Day comparison of deep work seconds versus distraction dwell</p>
          </div>
          <div className="flex items-center gap-4 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-emerald-700" />
              <span className="text-stone-600">Deep Work</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm bg-amber-500" />
              <span className="text-stone-600">Distraction</span>
            </div>
          </div>
        </div>

        {/* Bar chart grid */}
        <div className="grid grid-cols-7 gap-2 sm:gap-4 pt-4 border-t border-stone-100 items-end min-h-[140px]">
          {weeklyData?.daily_breakdown &&
            Object.entries(weeklyData.daily_breakdown).map(([date, data]: [string, any], idx) => {
              const deepH = Math.min(100, Math.round((data.DEEP_WORK / 220) * 100));
              const distH = Math.min(100, Math.round((data.DISTRACTION / 220) * 100));
              const dayLabel = new Date(date).toLocaleDateString('en-US', { weekday: 'short' });

              return (
                <div key={idx} className="flex flex-col items-center gap-2 group">
                  <div className="w-full flex items-end justify-center gap-1 h-28 bg-stone-50 rounded-lg p-1">
                    <div
                      className="w-1/2 bg-emerald-700 rounded-xs transition-all duration-500 group-hover:opacity-80"
                      style={{ height: `${Math.max(8, deepH)}%` }}
                      title={`Deep Work: ${data.DEEP_WORK}s`}
                    />
                    <div
                      className="w-1/2 bg-amber-500 rounded-xs transition-all duration-500 group-hover:opacity-80"
                      style={{ height: `${Math.max(8, distH)}%` }}
                      title={`Distraction: ${data.DISTRACTION}s`}
                    />
                  </div>
                  <div className="text-[11px] font-mono text-stone-600 font-medium">{dayLabel}</div>
                </div>
              );
            })}
        </div>
      </div>

      {/* Recent Reconstructed Sessions List */}
      <div className="bg-white rounded-xl border border-stone-200 shadow-xs p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-stone-900">Recent Reconstructed Sessions</h3>
            <p className="text-xs text-stone-500">Autonomous cognitive chunk boundaries</p>
          </div>
          <button
            onClick={onNavigateToTimeline}
            className="text-xs font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-1 cursor-pointer"
          >
            <span>Open Timeline</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-stone-100">
          {sessions.slice(0, 4).map((session) => (
            <div
              key={session.chunk_id}
              onClick={() => onSelectSession(session)}
              className="py-3 flex items-center justify-between gap-4 hover:bg-stone-50 rounded-lg px-2 -mx-2 transition-colors cursor-pointer group"
            >
              <div className="space-y-1 min-w-0">
                <div className="flex items-center gap-2 text-xs">
                  <span className="font-mono text-stone-500">{session.start_time}</span>
                  <span className="text-stone-400">·</span>
                  <span className="font-semibold text-stone-900 truncate">
                    {session.primary_task || session.anchor_app || 'Activity Session'}
                  </span>
                  <span className="text-stone-400">·</span>
                  <span className="text-[11px] font-mono text-stone-500">
                    {session.dominant_category}
                  </span>
                </div>
                <div className="text-xs text-stone-500 line-clamp-1">
                  {session.summary || 'Passive window transitions recorded.'}
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <span className="text-xs font-mono font-bold text-stone-700 tabular-nums">
                  {formatTime(session.duration_s)}
                </span>
                <span
                  className={`text-[11px] font-mono px-2 py-0.5 rounded font-medium ${
                    session.intent === 'DEEP_WORK' || session.intent === 'LEARNING'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {session.intent}
                </span>
                <ChevronRight className="w-4 h-4 text-stone-400 group-hover:text-stone-700 transition-colors" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
